#' @keywords internal
#' @useDynLib treesitter.rust, .registration = TRUE
"_PACKAGE"
