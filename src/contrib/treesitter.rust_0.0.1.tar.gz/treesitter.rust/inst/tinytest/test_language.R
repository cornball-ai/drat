library(treesitter.rust)

# -- language() returns a runtime-agnostic tree_sitter_language --
lang <- language()
expect_true(inherits(lang, "tree_sitter_language"))
expect_equal(lang$abi, 15L)
expect_equal(lang$name, "rust")
expect_true(inherits(lang$pointer, "externalptr"))

# -- Runtime interop needs an ABI-15 runtime. Posit's treesitter caps at ABI 14
# -- and cannot load this grammar, so exercise it through bonsaisitter if present.
if (requireNamespace("bonsaisitter", quietly = TRUE)) {
  p <- bonsaisitter::parser(language())
  tree <- bonsaisitter::parser_parse(p, "fn add(x: i32, y: i32) -> i32 { x + y }\n")
  root <- bonsaisitter::tree_root_node(tree)
  expect_equal(bonsaisitter::node_type(root), "source_file")
  fn <- bonsaisitter::node_child(root, 1)
  expect_equal(bonsaisitter::node_type(fn), "function_item")
}
