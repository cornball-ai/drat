library(treesitter.javascript)

# -- language() returns a runtime-agnostic tree_sitter_language --
lang <- language()
expect_true(inherits(lang, "tree_sitter_language"))
expect_equal(lang$abi, 15L)
expect_equal(lang$name, "javascript")
expect_true(inherits(lang$pointer, "externalptr"))

# -- Runtime interop needs an ABI-15 runtime. Posit's treesitter caps at ABI 14
# -- and cannot load this grammar, so exercise it through bonsaisitter if present.
if (requireNamespace("bonsaisitter", quietly = TRUE)) {
  p <- bonsaisitter::parser(language())
  tree <- bonsaisitter::parser_parse(p, "function add(x, y) { return x + y; }\n")
  root <- bonsaisitter::tree_root_node(tree)
  expect_equal(bonsaisitter::node_type(root), "program")
  fn <- bonsaisitter::node_child(root, 1)
  expect_equal(bonsaisitter::node_type(fn), "function_declaration")
}
