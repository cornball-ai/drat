#' @keywords internal
#' @useDynLib treesitter.javascript, .registration = TRUE
"_PACKAGE"
