# treesitter.javascript

A JavaScript grammar for [tree-sitter](https://tree-sitter.github.io/), packaged for
R. It ships the compiled `tree-sitter-javascript` grammar and exposes a single
function, `language()`, that returns a `tree_sitter_language` object. The grammar
carries no R dependencies.

## ABI compatibility

The bundled grammar is **ABI 15**, so it needs a tree-sitter runtime that
supports ABI 15, such as `bonsaisitter`. Posit's
[treesitter](https://cran.r-project.org/package=treesitter) package on CRAN
currently caps at ABI 14 and cannot load this grammar. (For contrast,
`treesitter.cpp` is ABI 14 and works with both runtimes.)

## Installation

```r
# install.packages("remotes")
remotes::install_github("cornball-ai/treesitter.javascript")
```

## Usage

```r
library(treesitter.javascript)

parser <- bonsaisitter::parser(language())
tree <- bonsaisitter::parser_parse(parser, "def add(x, y):\n    return x + y\n")
bonsaisitter::tree_root_node(tree)
```

## Attribution

The bundled grammar and tree-sitter C headers are by the tree-sitter authors
(MIT). See `LICENSE.note` and `PROVENANCE`.
