#' @title Function inspection
#' @description Structured inspection of R functions.

#' Inspect a function's internals
#'
#' Returns the formals, body, and environment of a function in a structured
#' format. For generic functions, lists available methods.
#'
#' @param fn A function object, or a character string naming a function.
#' @param package Optional package name to look up \code{fn} in.
#' @return A list with class \code{mirar_function}.
#' @export
inspect <- function(fn, package = NULL) {
    if (is.character(fn)) {
        fn_name <- fn
        if (!is.null(package)) {
            ns <- getNamespace(package)
            fn_obj <- get(fn_name, envir = ns)
        } else {
            fn_obj <- get(fn_name, envir = parent.frame())
        }
    } else {
        fn_name <- deparse(substitute(fn))
        fn_obj <- fn
    }

    if (!is.function(fn_obj)) {
        stop("'", fn_name, "' is not a function.", call. = FALSE)
    }

    fmls <- formals(fn_obj)
    args <- if (length(fmls) > 0L) {
        data.frame(
                   name = names(fmls),
                   default = vapply(fmls, function(f) {
            if (is.symbol(f) && nchar(as.character(f)) == 0L) {
                ""
            } else {
                deparse(f, width.cutoff = 60L)[1L]
            }
        }, character(1L)),
                   stringsAsFactors = FALSE, row.names = NULL
        )
    } else {
        data.frame(name = character(), default = character(),
                   stringsAsFactors = FALSE)
    }

    fn_body <- body(fn_obj)
    body_lines <- deparse(fn_body, width.cutoff = 80L)
    n_lines <- length(body_lines)

    fn_env <- environment(fn_obj)
    if (!is.null(fn_env)) {
        env_name <- environmentName(fn_env)
    } else {
        env_name <- "NULL"
    }

    is_generic <- tryCatch({
        isGeneric(fn_name)
    }, error = function(e) FALSE)

    meths <- character(0L)
    if (is_generic) {
        meths <- tryCatch(
                          as.character(utils::methods(fn_name)),
                          error = function(e) character(0L)
        )
    } else {
        meths <- tryCatch(
                          as.character(utils::methods(fn_name)),
                          error = function(e) character(0L)
        )
    }

    result <- list(
                   name = fn_name,
                   args = args,
                   body_lines = n_lines,
                   environment = env_name,
                   is_generic = is_generic || length(meths) > 0L,
                   methods = meths,
                   source = if (n_lines <= 30L) body_lines else NULL
    )
    class(result) <- "mirar_function"
    result
}

#' @export
print.mirar_function <- function(x, ...) {
    cat(sprintf("%s()\n", x$name))
    cat(sprintf("  env: %s\n", x$environment))
    if (nrow(x$args) > 0L) {
        cat("  args:\n")
        for (i in seq_len(nrow(x$args))) {
            if (nchar(x$args$default[i]) > 0L) {
                cat(sprintf("    %s = %s\n", x$args$name[i], x$args$default[i]))
            } else {
                cat(sprintf("    %s\n", x$args$name[i]))
            }
        }
    }
    cat(sprintf("  body: %d lines\n", x$body_lines))
    if (length(x$methods) > 0L) {
        cat(sprintf("  methods: %s\n", paste(x$methods, collapse = ", ")))
    }
    if (!is.null(x$source)) {
        cat("  source:\n")
        for (line in x$source) {
            cat("    ", line, "\n", sep = "")
        }
    }
    invisible(x)
}
