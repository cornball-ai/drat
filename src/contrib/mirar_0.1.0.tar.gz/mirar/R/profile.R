#' @title Sampling profiler
#' @description Structured profiling of an expression via Rprof().

#' Profile an expression and return where the time went
#'
#' Runs \code{expr} under \code{Rprof()}, R's sampling profiler, and
#' returns the time spent per function as a data frame: a tiny profvis.
#' Self time is time spent in the function's own code; total time includes
#' everything it called.
#'
#' Note this masks \code{stats::profile()} (likelihood profiling) if mirar
#' is attached; call it as \code{mirar::profile()}.
#'
#' @param expr Expression to profile. Evaluated once; its value is
#'   discarded, like \code{system.time()}.
#' @param interval Sampling interval in seconds. Expressions finishing
#'   inside one interval produce zero samples; lower it for short code.
#' @return A list with class \code{mirar_profile}: \code{samples} (a
#'   data.frame with columns fun, self_time, self_pct, total_time,
#'   total_pct, ordered by self time), \code{elapsed}, \code{sampling_time},
#'   and \code{interval}.
#' @examples
#' p <- mirar::profile({
#'     for (i in 1:50) d <- dist(matrix(rnorm(2000), ncol = 10))
#' })
#' p
#' @importFrom utils Rprof summaryRprof head
#' @export
profile <- function(expr, interval = 0.02) {
    prof_file <- tempfile("mirar-profile-", fileext = ".out")
    on.exit(unlink(prof_file), add = TRUE)

    elapsed <- proc.time()[["elapsed"]]
    Rprof(prof_file, interval = interval)
    tryCatch(expr, finally = Rprof(NULL))
    elapsed <- proc.time()[["elapsed"]] - elapsed

    prof <- tryCatch(summaryRprof(prof_file), error = function(e) NULL)

    if (is.null(prof) || nrow(prof$by.self) == 0L) {
        samples <- data.frame(fun = character(), self_time = double(),
                              self_pct = double(), total_time = double(),
                              total_pct = double(), stringsAsFactors = FALSE)
        sampling_time <- 0
    } else {
        by_self <- prof$by.self
        samples <- data.frame(fun = gsub("\"", "", rownames(by_self)),
                              self_time = by_self$self.time,
                              self_pct = by_self$self.pct,
                              total_time = by_self$total.time,
                              total_pct = by_self$total.pct,
                              stringsAsFactors = FALSE)
        rownames(samples) <- NULL
        sampling_time <- prof$sampling.time
    }

    result <- list(samples = samples, elapsed = elapsed,
                   sampling_time = sampling_time, interval = interval)
    class(result) <- "mirar_profile"
    result
}

#' @export
print.mirar_profile <- function(x, n = 10L, ...) {
    cat(sprintf("Profile: %.2fs elapsed, %.2fs sampled at %.0f ms\n",
                x$elapsed, x$sampling_time, x$interval * 1000))
    if (nrow(x$samples) == 0L) {
        cat("  no samples captured (finished within one interval; lower `interval`)\n")
    } else {
        print(head(x$samples, n), row.names = FALSE)
        if (nrow(x$samples) > n) {
            cat(sprintf("  ... and %d more rows\n", nrow(x$samples) - n))
        }
    }
    invisible(x)
}
