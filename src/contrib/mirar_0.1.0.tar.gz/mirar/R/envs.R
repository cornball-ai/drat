#' @title Environment inspection
#' @description Walk and inspect R environment chains.

#' Show the environment chain of a function or environment
#'
#' Walks the parent environment chain and returns a data.frame of
#' environment names and object counts.
#'
#' @param x A function or environment.
#' @param max_depth Maximum number of parents to walk. Default 20.
#' @return A data.frame with columns: depth, name, n_objects.
#' @export
env_chain <- function(x, max_depth = 20L) {
    if (is.function(x)) {
        env <- environment(x)
    } else if (is.environment(x)) {
        env <- x
    } else {
        stop("'x' must be a function or environment.", call. = FALSE)
    }

    rows <- list()
    depth <- 0L
    while (!is.null(env) && depth < max_depth) {
        nm <- environmentName(env)
        if (nchar(nm) == 0L) {
            nm <- format(env)
        }
        n <- length(ls(env, all.names = TRUE))
        rows <- c(rows, list(data.frame(depth = depth, name = nm,
                                        n_objects = n,
                                        stringsAsFactors = FALSE)))
        if (identical(env, emptyenv())) {
            break
        }
        env <- parent.env(env)
        depth <- depth + 1L
    }

    do.call(rbind, rows)
}
