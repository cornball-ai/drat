#' @title Error inspection
#' @description Structured access to R error state.

#' Get the last error as a structured object
#'
#' Captures the last error message, call, and traceback into a structured
#' list an agent can parse.
#'
#' @return A list with class \code{mirar_error}, or \code{NULL} if no error
#'   has occurred.
#' @export
last_error <- function() {
    # geterrmessage() returns "" if no error
    msg <- geterrmessage()
    if (nchar(msg) == 0L) {
        return(NULL)
    }

    # .Traceback is set by traceback()
    tb <- tryCatch(get(".Traceback", envir = baseenv()),
                   error = function(e) NULL)

    tb_lines <- if (!is.null(tb)) {
        vapply(tb, function(x) paste(deparse(x), collapse = " "), character(1L))
    } else {
        character(0L)
    }

    result <- list(message = trimws(msg), traceback = tb_lines)
    class(result) <- "mirar_error"
    result
}

#' @export
print.mirar_error <- function(x, ...) {
    cat("Error:", x$message, "\n")
    if (length(x$traceback) > 0L) {
        cat("Traceback:\n")
        for (i in seq_along(x$traceback)) {
            cat(sprintf("  %d: %s\n", i, x$traceback[i]))
        }
    }
    invisible(x)
}
