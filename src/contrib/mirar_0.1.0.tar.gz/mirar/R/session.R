#' @title Session inspection
#' @description Structured summaries of the R session state.

#' List loaded packages with versions and dependencies
#'
#' @return A data.frame with columns: package, version, priority, depends,
#'   imports.
#' @export
loaded <- function() {
    pkgs <- loadedNamespaces()
    rows <- lapply(pkgs, function(p) {
        ver <- tryCatch(as.character(packageVersion(p)),
                        error = function(e) NA_character_)
        desc <- tryCatch(packageDescription(p, fields = c("Priority",
                    "Depends",
                    "Imports")),
                         error = function(e) {
            list(Priority = NA_character_, Depends = NA_character_,
                 Imports = NA_character_)
        })
        data.frame(package = p, version = ver,
                   priority = if (is.null(desc$Priority)) NA_character_
            else desc$Priority,
                   depends = if (is.null(desc$Depends)) NA_character_
            else desc$Depends,
                   imports = if (is.null(desc$Imports)) NA_character_
            else desc$Imports,
                   stringsAsFactors = FALSE)
    })
    out <- do.call(rbind, rows)
    out[order(out$package),]
}

#' Summarize current session for an agent
#'
#' Returns a structured overview: R version, platform, working directory,
#' loaded packages, and workspace object count.
#'
#' @param envir Environment to count objects in. Default: \code{.GlobalEnv}.
#' @return A list with class \code{mirar_session}.
#' @export
session <- function(envir = .GlobalEnv) {
    ri <- R.Version()
    result <- list(r_version = paste0(ri$major, ".", ri$minor),
                   platform = ri$platform, os = Sys.info()[["sysname"]],
                   wd = getwd(), pid = Sys.getpid(),
                   locale = Sys.getlocale("LC_CTYPE"),
                   n_objects = length(ls(envir = envir)),
                   n_loaded_packages = length(loadedNamespaces()),
                   search_path = search())
    class(result) <- "mirar_session"
    result
}

#' @export
print.mirar_session <- function(x, ...) {
    cat(sprintf("R %s on %s (%s)\n", x$r_version, x$os, x$platform))
    cat(sprintf("  wd: %s\n", x$wd))
    cat(sprintf("  objects: %d\n", x$n_objects))
    cat(sprintf("  packages: %d loaded\n", x$n_loaded_packages))
    cat(sprintf("  search: %s\n", paste(x$search_path, collapse = " -> ")))
    invisible(x)
}
