#' @title Workspace inspection
#' @description Structured summaries of objects in an R environment.

#' List objects in an environment with metadata
#'
#' Returns a data.frame summarizing every object in the environment:
#' name, class, type, dimensions, and size in bytes.
#'
#' @param envir Environment to inspect. Default: \code{.GlobalEnv}.
#' @param pattern Optional regex to filter object names.
#' @return A data.frame with columns: name, class, type, nrow, ncol, length,
#'   size_bytes.
#' @export
workspace <- function(envir = .GlobalEnv, pattern = NULL) {
    nms <- ls(envir = envir, all.names = FALSE)
    if (!is.null(pattern)) {
        nms <- grep(pattern, nms, value = TRUE)
    }
    if (length(nms) == 0L) {
        return(data.frame(name = character(), class = character(),
                          type = character(), nrow = integer(),
                          ncol = integer(), length = integer(),
                          size_bytes = numeric(), stringsAsFactors = FALSE))
    }

    rows <- lapply(nms, function(nm) {
        obj <- get(nm, envir = envir)
        cl <- paste(class(obj), collapse = ", ")
        tp <- typeof(obj)
        nr <- if (!is.null(nrow(obj))) nrow(obj) else NA_integer_
        nc <- if (!is.null(ncol(obj))) ncol(obj) else NA_integer_
        len <- length(obj)
        sz <- as.numeric(object.size(obj))
        data.frame(name = nm, class = cl, type = tp, nrow = nr, ncol = nc,
                   length = len, size_bytes = sz, stringsAsFactors = FALSE)
    })

    do.call(rbind, rows)
}

#' Examine a single object in detail
#'
#' Returns a structured list describing an object: class, type, dimensions,
#' size, and content-specific metadata (column names for data.frames,
#' coefficients for models, element names for lists).
#'
#' @param x An R object, or a character name to look up in \code{envir}.
#' @param envir Environment to look up \code{x} if it is a character string.
#' @return A list with class \code{mirar_examination}.
#' @export
examine <- function(x, envir = .GlobalEnv) {
    if (is.character(x) && length(x) == 1L) {
        nm <- x
        if (!exists(nm, envir = envir)) {
            stop("Object '", nm, "' not found.", call. = FALSE)
        }
        obj <- get(nm, envir = envir)
    } else {
        nm <- deparse(substitute(x))
        obj <- x
    }

    result <- list(name = nm, class = class(obj), type = typeof(obj),
                   length = length(obj),
                   size_bytes = as.numeric(object.size(obj)))

    if (!is.null(dim(obj))) {
        result$dim <- dim(obj)
    }

    if (is.data.frame(obj)) {
        result$columns <- data.frame(
                                     name = names(obj),
                                     class = vapply(obj, function(col) paste(class(col), collapse = ", "),
                character(1L)),
                                     n_na = vapply(obj, function(col) sum(is.na(col)), integer(1L)),
                                     stringsAsFactors = FALSE, row.names = NULL
        )
    } else if (is.list(obj) && !is.data.frame(obj)) {
        result$names <- names(obj)
        result$element_classes <- vapply(obj, function(el) {
            paste(class(el), collapse = ", ")
        }, character(1L))
    } else if (is.function(obj)) {
        result$formals <- names(formals(obj))
        fn_env <- environment(obj)
        if (!is.null(fn_env)) {
            result$environment <- environmentName(fn_env)
        }
    } else if (is.atomic(obj) && length(obj) <= 10L) {
        result$value <- obj
    } else if (is.atomic(obj)) {
        result$head <- utils::head(obj, 6L)
        result$summary <- as.list(summary(obj))
    }

    if (isS4(obj)) {
        result$slots <- methods::slotNames(obj)
    }

    avail <- tryCatch(utils::methods(class = class(obj)[1L]),
                      error = function(e) character(0L))
    if (length(avail) > 0L) {
        result$methods <- as.character(avail)
    }

    class(result) <- "mirar_examination"
    result
}

#' @export
print.mirar_examination <- function(x, ...) {
    cat(sprintf("%s <%s>\n", x$name, paste(x$class, collapse = ", ")))
    cat(sprintf("  type: %s\n", x$type))
    if (!is.null(x$dim)) {
        cat(sprintf("  dim: %s\n", paste(x$dim, collapse = " x ")))
    }
    cat(sprintf("  length: %d\n", x$length))
    cat(sprintf("  size: %s\n", format_bytes(x$size_bytes)))

    if (!is.null(x$columns)) {
        cat("  columns:\n")
        for (i in seq_len(nrow(x$columns))) {
            na_str <- if (x$columns$n_na[i] > 0L) {
                sprintf(" (%d NA)", x$columns$n_na[i])
            } else {
                ""
            }
            cat(sprintf("    %s <%s>%s\n", x$columns$name[i],
                        x$columns$class[i], na_str))
        }
    }

    if (!is.null(x$names) && length(x$names) > 0L) {
        cat(sprintf("  names: %s\n", paste(x$names, collapse = ", ")))
    }

    if (!is.null(x$formals)) {
        cat(sprintf("  args: %s\n", paste(x$formals, collapse = ", ")))
    }
    if (!is.null(x$environment)) {
        cat(sprintf("  env: %s\n", x$environment))
    }

    if (!is.null(x$value)) {
        cat(sprintf("  value: %s\n", paste(x$value, collapse = ", ")))
    } else if (!is.null(x$head)) {
        cat(sprintf("  head: %s\n", paste(x$head, collapse = ", ")))
    }

    if (!is.null(x$slots)) {
        cat(sprintf("  slots: %s\n", paste(x$slots, collapse = ", ")))
    }

    if (!is.null(x$methods) && length(x$methods) > 0L) {
        cat(sprintf("  methods: %s\n",
                    paste(utils::head(x$methods, 10L), collapse = ", ")))
        if (length(x$methods) > 10L) {
            cat(sprintf("  ... and %d more\n", length(x$methods) - 10L))
        }
    }

    invisible(x)
}

#' Format bytes as human-readable string
#' @noRd
format_bytes <- function(bytes) {
    if (bytes < 1024) {
        return(sprintf("%d B", bytes))
    }
    if (bytes < 1024 ^ 2) {
        return(sprintf("%.1f KB", bytes / 1024))
    }
    if (bytes < 1024 ^ 3) {
        return(sprintf("%.1f MB", bytes / 1024 ^ 2))
    }
    sprintf("%.1f GB", bytes / 1024 ^ 3)
}
