# mirar

Structured runtime inspection for R sessions. Zero dependencies.

mirar ("to look") wraps base R's scattered introspection functions into consistent, agent-friendly data frames. Instead of writing ad-hoc `str()` and `ls()` calls, an agent gets structured output it can parse without guessing.

Part of [cerebro](https://github.com/cornball-ai/cerebro), the AI agent toolchain for R.

## Install

```r
remotes::install_github("cornball-ai/mirar")
```

## What it does

### Workspace

See everything in an environment at a glance:

```r
mirar::workspace()
#>   name       class      type    nrow ncol length size_bytes
#>   df         data.frame list    1000    5      5      42400
#>   model      lm         list      NA   NA     12       8200
#>   x          numeric    double    NA   NA    100        848
```

### Examine

Drill into a single object. Column types for data frames, formals for functions, slots for S4:

```r
mirar::examine("df")
#> df <data.frame>
#>   type: list
#>   dim: 1000 x 5
#>   length: 5
#>   size: 41.4 KB
#>   columns:
#>     id <integer>
#>     name <character>
#>     value <numeric>
#>     date <Date>
#>     flag <logical> (12 NA)
```

### Inspect functions

Pull apart a function's args, body, environment, and methods:

```r
mirar::inspect("lm", package = "stats")
#> lm()
#>   env: stats
#>   args:
#>     formula
#>     data
#>     subset
#>     weights
#>     ...
#>   body: 53 lines
#>   methods: lm.fit, lm.wfit
```

### Session

Snapshot the current R session state:

```r
mirar::session()
#> R 4.4.2 on Linux (x86_64-pc-linux-gnu)
#>   wd: /home/troy/myproject
#>   objects: 14
#>   packages: 23 loaded
```

### Environment chains

Walk the parent environment chain of a function or environment:

```r
mirar::env_chain(stats::lm)
#>   depth     name n_objects
#>       0    stats       453
#>       1 imports:stats    7
#>       2 namespace:base 1324
#>       3     R_GlobalEnv   14
#>       ...
```

### Profile

A tiny profvis. Run an expression under R's sampling profiler and get back a data frame of where the time went:

```r
mirar::profile(saber::src_symbols("~/bonsaisitter"))
#> Profile: 2.10s elapsed, 2.05s sampled at 20 ms
#>           fun self_time self_pct total_time total_pct
#>          %in%      0.44    21.46       0.63     30.73
#>  [.data.frame      0.30    14.63       1.20     58.54
#>  ...
```

### Last error

Grab the most recent error as a structured object:

```r
mirar::last_error()
#> Error: object 'foo' not found
#> Traceback:
#>   1: eval(expr, envir)
#>   2: my_function(x)
```

## Why this exists

R already gives you `ls()`, `str()`, `class()`, `environment()`, `traceback()`, and dozens more. But they all return different formats. Some print to console. Some return lists. Some return character vectors.

An agent shouldn't have to write bespoke parsing for each one. mirar gives every introspection query the same shape: a data frame or a structured list with a print method.

## Sister packages

| Package | Purpose |
|---|---|
| [saber](https://github.com/cornball-ai/saber) | AST symbol index, blast radius, package introspection |
| [pensar](https://github.com/cornball-ai/pensar) | Knowledge graph from markdown |
| [llm.api](https://github.com/cornball-ai/llm.api) | Agent runtime and chat loop |

## License

Apache-2.0
