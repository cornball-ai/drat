# Tests for workspace.R

library(mirar)

# --- workspace on a test environment ---

e <- new.env(parent = emptyenv())
e$x <- 1:10
e$df <- data.frame(a = 1:3, b = letters[1:3])
e$fn <- function(x) x + 1

ws <- workspace(envir = e)
expect_true(is.data.frame(ws))
expect_equal(nrow(ws), 3L)
expect_true("name" %in% names(ws))
expect_true("class" %in% names(ws))
expect_true("size_bytes" %in% names(ws))
expect_true(all(c("x", "df", "fn") %in% ws$name))

# data.frame has nrow/ncol
df_row <- ws[ws$name == "df", ]
expect_equal(df_row$nrow, 3L)
expect_equal(df_row$ncol, 2L)

# pattern filter
ws2 <- workspace(envir = e, pattern = "^d")
expect_equal(nrow(ws2), 1L)
expect_equal(ws2$name, "df")

# empty environment
empty <- new.env(parent = emptyenv())
ws3 <- workspace(envir = empty)
expect_equal(nrow(ws3), 0L)

# --- examine ---

ex <- examine("df", envir = e)
expect_true(inherits(ex, "mirar_examination"))
expect_equal(ex$name, "df")
expect_equal(ex$class, "data.frame")
expect_true(!is.null(ex$columns))
expect_equal(nrow(ex$columns), 2L)

# examine a function
ex_fn <- examine("fn", envir = e)
expect_true("formals" %in% names(ex_fn))
expect_equal(ex_fn$formals, "x")

# examine a short vector
ex_vec <- examine("x", envir = e)
expect_true(!is.null(ex_vec$value))
expect_equal(ex_vec$value, 1:10)

# examine non-existent
expect_error(examine("nope", envir = e))
