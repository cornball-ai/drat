# Tests for errors.R

library(mirar)

# --- last_error when no error has occurred ---

# Fresh session may or may not have an error
result <- last_error()
# Either NULL or a mirar_error, both are valid
if (!is.null(result)) {
    expect_true(inherits(result, "mirar_error"))
    expect_true(nchar(result$message) > 0L)
}

# --- trigger an error and capture it ---

tryCatch(stop("test error from mirar"), error = function(e) NULL)
err <- last_error()
expect_true(inherits(err, "mirar_error"))
expect_true(grepl("test error from mirar", err$message))
