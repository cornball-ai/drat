# Tests for envs.R

library(mirar)

# --- env_chain on a function ---

fn <- function() NULL
chain <- env_chain(fn)
expect_true(is.data.frame(chain))
expect_true(nrow(chain) > 0L)
expect_true("depth" %in% names(chain))
expect_true("name" %in% names(chain))
expect_true("n_objects" %in% names(chain))

# --- env_chain on an environment ---

e <- new.env(parent = globalenv())
e$a <- 1
chain2 <- env_chain(e)
expect_true(nrow(chain2) >= 2L)
expect_equal(chain2$n_objects[1], 1L)

# --- errors on bad input ---

expect_error(env_chain(42))
