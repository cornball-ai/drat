# profile() wraps Rprof(); skip everywhere profiling support is absent
# (R built without --enable-R-profiling).

has_prof <- tryCatch({
    tf <- tempfile()
    utils::Rprof(tf)
    utils::Rprof(NULL)
    unlink(tf)
    TRUE
}, error = function(e) FALSE)

if (has_prof) {
    # CPU-bound work for ~0.15s guarantees samples at the 10ms interval
    p <- mirar::profile({
        t0 <- proc.time()[["elapsed"]]
        while (proc.time()[["elapsed"]] - t0 < 0.15) {
            x <- sum(runif(10000))
        }
    }, interval = 0.01)

    expect_true(inherits(p, "mirar_profile"))
    expect_identical(names(p$samples),
                     c("fun", "self_time", "self_pct", "total_time",
                       "total_pct"))
    expect_true(nrow(p$samples) > 0L)
    expect_true(p$elapsed >= 0.15)
    expect_true(p$sampling_time > 0)

    # Ordered by self time, descending
    expect_true(!is.unsorted(rev(p$samples$self_time)))

    # print method runs and returns invisibly
    out <- capture.output(print(p))
    expect_true(any(grepl("^Profile:", out)))

    # An expression finishing within one interval yields zero samples,
    # not an error
    p0 <- mirar::profile(1 + 1)
    expect_identical(nrow(p0$samples), 0L)
    out0 <- capture.output(print(p0))
    expect_true(any(grepl("no samples captured", out0)))
}
