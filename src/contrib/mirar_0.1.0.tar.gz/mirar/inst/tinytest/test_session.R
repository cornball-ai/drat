# Tests for session.R

library(mirar)

# --- loaded ---

ld <- loaded()
expect_true(is.data.frame(ld))
expect_true(nrow(ld) > 0L)
expect_true("package" %in% names(ld))
expect_true("version" %in% names(ld))
expect_true("base" %in% ld$package)
expect_true("mirar" %in% ld$package)

# --- session ---

s <- session()
expect_true(inherits(s, "mirar_session"))
expect_true(nchar(s$r_version) > 0L)
expect_true(nchar(s$wd) > 0L)
expect_true(s$n_loaded_packages > 0L)
expect_true(length(s$search_path) > 0L)
