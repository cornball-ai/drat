# Tests for functions.R

library(mirar)

# --- inspect a simple function ---

my_fn <- function(x, y = 10) x + y

result <- inspect(my_fn)
expect_true(inherits(result, "mirar_function"))
expect_equal(nrow(result$args), 2L)
expect_equal(result$args$name[1], "x")
expect_equal(result$args$name[2], "y")
expect_equal(result$args$default[2], "10")
expect_true(result$body_lines > 0L)

# --- inspect by name from a package ---

result2 <- inspect("ls", package = "base")
expect_true(inherits(result2, "mirar_function"))
expect_equal(result2$name, "ls")
expect_true(nrow(result2$args) > 0L)

# --- inspect a generic ---

result3 <- inspect("print", package = "base")
expect_true(length(result3$methods) > 0L)

# --- non-function errors ---

expect_error(inspect(42))
