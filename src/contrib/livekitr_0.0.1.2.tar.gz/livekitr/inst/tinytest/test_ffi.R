library(livekitr)

expect_true(is.logical(livekit_available()))
expect_equal(length(livekit_available()), 1L)

## LIVEKIT_FFI_LIB overrides the library lookup
local({
    old <- Sys.getenv("LIVEKIT_FFI_LIB", NA_character_)
    on.exit(if (is.na(old)) {
        Sys.unsetenv("LIVEKIT_FFI_LIB")
    } else {
        Sys.setenv(LIVEKIT_FFI_LIB = old)
    })
    Sys.setenv(LIVEKIT_FFI_LIB = "/nonexistent/liblivekit_ffi.so")
    expect_equal(livekitr:::ffi_path(), "/nonexistent/liblivekit_ffi.so")
})

## PCM conversion needs no library
pcm_bytes <- livekitr:::pcm_bytes
samples <- c(0L, 1L, -1L, 32767L, -32768L, 1234L)
expect_equal(readBin(pcm_bytes(samples), "integer", n = 6L, size = 2L),
             samples)
expect_equal(pcm_bytes(as.raw(1:4)), as.raw(1:4))
expect_error(pcm_bytes(as.raw(1:3)), "whole 16-bit samples")
expect_error(pcm_bytes(c(0L, 32768L)), "between -32768 and 32767")
expect_error(pcm_bytes(c(0L, NA)), "between -32768 and 32767")
expect_error(pcm_bytes(c(0.5, 1)), "integer vector")

## the native log filter reads the severity of RProtoBuf-encoded events
livekitr:::proto_load()
pb <- livekitr:::pb
log_event <- function(levels) {
    records <- lapply(levels, function(level) {
        pb("LogRecord", level = level, target = "libwebrtc",
           message = "connection state changed")
    })
    RProtoBuf::serialize(pb("FfiEvent", logs = pb("LogBatch",
                                                  records = records)), NULL)
}
severity <- function(bytes) .Call(livekitr:::livekitr_log_severity, bytes)
expect_equal(severity(log_event(3L)), 3L)
expect_equal(severity(log_event(0L)), 0L)
expect_equal(severity(log_event(c(4L, 3L, 1L, 3L))), 1L)
expect_equal(severity(log_event(rep(4L, 40L))), 4L)
## anything that is not a log batch is never filtered
expect_equal(severity(RProtoBuf::serialize(pb("FfiEvent",
    capture_audio_frame = pb("CaptureAudioFrameCallback", async_id = 7)),
    NULL)), -1L)
expect_equal(severity(raw()), -1L)
expect_equal(severity(as.raw(c(0x92, 0x01, 0x05, 0x0a))), -1L)
expect_equal(severity(head(log_event(c(3L, 3L)), -1L)), -1L)

## room options: defaults, the ICE transport policy, and E2EE settings
room_options <- livekitr:::room_options
options <- room_options(list(), NULL)
expect_true(options$auto_subscribe)
expect_false(options$has("rtc_config"))
expect_false(options$has("encryption"))
## IceTransportType TRANSPORT_RELAY = 0, TRANSPORT_ALL = 2
expect_equal(room_options(list(ice_transport = "relay"),
                          NULL)$rtc_config$ice_transport_type, 0L)
expect_equal(room_options(list(ice_transport = "all"),
                          NULL)$rtc_config$ice_transport_type, 2L)
expect_error(room_options(list(ice_transport = "direct"), NULL), "should be")
expect_error(room_options(list(1), NULL), "named list")
## the per-participant settings MatrixRTC clients use
provider <- room_options(list(), list(kdf = "hkdf",
    key_ring_size = 256L))$encryption$key_provider_options
expect_false(provider$has("shared_key"))
expect_equal(provider$key_derivation_function, 1L)
expect_equal(provider$key_ring_size, 256L)
expect_equal(rawToChar(provider$ratchet_salt), "LKFrameEncryptionKey")
shared <- room_options(list(), "secret")$encryption$key_provider_options
expect_equal(rawToChar(shared$shared_key), "secret")
expect_equal(shared$key_derivation_function, 0L)
expect_error(room_options(list(), list(cipher = "x")), "unknown e2ee option")

## options(livekitr.log = ) maps to the level the filter keeps
local({
    old <- options(livekitr.log = "none")
    on.exit(options(old))
    expect_equal(livekitr:::log_threshold(), -1L)
    options(livekitr.log = "error")
    expect_equal(livekitr:::log_threshold(), 0L)
    options(livekitr.log = "trace")
    expect_equal(livekitr:::log_threshold(), 4L)
    options(livekitr.log = "bogus")
    expect_equal(livekitr:::log_threshold(), 1L)
    options(livekitr.log = NULL)
    expect_equal(livekitr:::log_threshold(), 1L)
})

if (!livekit_available()) {
    exit_file("livekit-ffi library not available")
}

## schemas load and a request round-trips through the native library
source <- livekitr:::ffi_call("new_audio_source",
    livekitr:::pb("NewAudioSourceRequest", type = 0L, sample_rate = 48000L,
                  num_channels = 1L, queue_size_ms = 1000L))
handle <- source$source$handle$id
expect_true(handle > 0)

## reading samples back from a native address: the path received frames
## take. The handle is unknown to livekit-ffi, so dropping it is a no-op.
bytes <- pcm_bytes(samples)
expect_equal(.Call(livekitr:::livekitr_take_frame,
                   .Call(livekitr:::livekitr_address, bytes), 6L, 1e15),
             samples)
expect_error(.Call(livekitr:::livekitr_take_frame, 0, 6L, 1e15),
             "invalid audio frame")
expect_error(.Call(livekitr:::livekitr_drop_handle, -1), "unsigned integer")

## an asynchronous request completes through the native event queue
tone <- as.integer(8000 * sin(2 * pi * 440 * seq_len(4800L) / 48000))
bytes <- pcm_bytes(tone)
response <- livekitr:::ffi_call("capture_audio_frame",
    livekitr:::pb("CaptureAudioFrameRequest", source_handle = handle,
        buffer = livekitr:::pb("AudioFrameBufferInfo",
            data_ptr = .Call(livekitr:::livekitr_address, bytes),
            num_channels = 1L, sample_rate = 48000L,
            samples_per_channel = length(tone))))
callback <- livekitr:::await(response$async_id, 10, "capturing audio")
expect_false(callback$has("error"))
expect_true(.Call(livekitr:::livekitr_drop_handle, as.numeric(handle)))
expect_false(.Call(livekitr:::livekitr_drop_handle, as.numeric(handle)))

## a malformed request is refused, not fatal
expect_error(.Call(livekitr:::livekitr_request, as.raw(c(0xff, 0xff, 0xff))),
             "rejected the request")

## joining fails cleanly when nothing is listening
expect_error(lk_connect("ws://127.0.0.1:1", "not-a-token",
                        opts = list(join_retries = 0L,
                                    connect_timeout_ms = 2000)),
             "could not join the room")
expect_error(lk_connect("ws://127.0.0.1:1", "t", opts = list(bogus = 1)),
             "unknown room option")
expect_error(lk_poll("not a session"), "lk_connect")
