library(livekitr)

## Needs a LiveKit server. With Docker:
##   docker run --rm --network host livekit/livekit-server --dev \
##       --bind 127.0.0.1 --node-ip 127.0.0.1
## then LIVEKITR_TEST_URL=ws://127.0.0.1:7880. The key and secret default
## to the dev server's.
url <- Sys.getenv("LIVEKITR_TEST_URL", "")
if (!at_home() || !nzchar(url) || !livekit_available()) {
    exit_file("no LiveKit test server (set LIVEKITR_TEST_URL)")
}
api_key <- Sys.getenv("LIVEKITR_TEST_KEY", "devkey")
api_secret <- Sys.getenv("LIVEKITR_TEST_SECRET", "secret")

rate <- 48000L
tone <- as.integer(8000 * sin(2 * pi * 440 * seq_len(2L * rate) / rate))

new_room <- function(prefix) {
    paste0(prefix, "-", Sys.getpid(), "-", as.integer(Sys.time()))
}
join <- function(room, identity, ...) {
    lk_connect(url, lk_mint_token(api_key, api_secret, room = room,
                                  identity = identity), ...)
}
## Poll every session for `seconds`; return the events seen per session.
poll_all <- function(sessions, seconds) {
    events <- lapply(sessions, function(s) list())
    end <- Sys.time() + seconds
    while (Sys.time() < end) {
        for (i in seq_along(sessions)) {
            events[[i]] <- c(events[[i]], lk_poll(sessions[[i]], 0.02))
        }
    }
    lapply(events, function(e) vapply(e, function(x) x$type, ""))
}
## Strongest frequency (Hz) in the loudest second of `pcm`.
peak_hz <- function(pcm, rate) {
    energy <- stats::filter(abs(pcm), rep(1 / rate, rate), sides = 1)
    last <- which.max(energy)
    spectrum <- Mod(stats::fft(pcm[(last - rate + 1L):last]))
    which.max(spectrum[seq_len(rate %/% 2L)]) - 1L
}

## --- two participants: publish, subscribe, attribution, resampling ---
room <- new_room("livekitr-test")
alice <- join(room, "alice")
bob <- join(room, "bob")
expect_inherits(alice, "lk_session")
expect_equal(bob$identity, "bob")
expect_equal(names(bob$participants), "alice")
expect_stdout(print(bob), "room '.*' as 'bob' \\(connected\\)")

heard <- list()
lk_on_audio(bob, function(pcm, info) {
    heard[[length(heard) + 1L]] <<- list(pcm = pcm, info = info)
})

## an empty publish announces the track without sending audio
lk_publish_pcm(alice, integer())
events <- poll_all(list(alice, bob), 1)
expect_true("local_track_published" %in% events[[1L]])
expect_true(all(c("track_published", "track_subscribed") %in% events[[2L]]))

lk_publish_pcm(alice, tone)
poll_all(list(alice, bob), 2.5)
pcm <- unlist(lapply(heard, function(h) h$pcm))
expect_true(length(pcm) > rate)
expect_true(abs(peak_hz(pcm, rate) - 440) <= 2)
expect_true(sum(abs(pcm) > 1000L) > 1.5 * rate)
info <- heard[[1L]]$info
expect_equal(info$identity, "alice")
expect_equal(info$sample_rate, 48000L)
expect_equal(info$channels, 1L)
expect_true(startsWith(info$track_sid, "TR_"))

## the published format is fixed by the first call
expect_error(lk_publish_pcm(alice, tone, sample_rate = 16000L),
             "published track is 48000 Hz")

## asking for another delivery format resamples natively
heard <- list()
lk_on_audio(bob, function(pcm, info) {
    heard[[length(heard) + 1L]] <<- list(pcm = pcm, info = info)
}, sample_rate = 16000L)
lk_publish_pcm(alice, tone, wait = FALSE)
poll_all(list(alice, bob), 3)
pcm <- unlist(lapply(heard, function(h) h$pcm))
expect_equal(heard[[1L]]$info$sample_rate, 16000L)
expect_true(abs(peak_hz(pcm, 16000L) - 440) <= 2)

## no callback, no audio
lk_on_audio(bob, NULL)
lk_publish_pcm(alice, tone[seq_len(rate %/% 2L)])
poll_all(list(alice, bob), 1)
expect_equal(length(bob$audio), 0L)

lk_disconnect(alice)
events <- poll_all(list(bob), 2)
expect_true("participant_disconnected" %in% events[[1L]])
expect_equal(length(bob$participants), 0L)
lk_disconnect(bob)
expect_null(lk_disconnect(bob))
expect_error(lk_poll(bob), "left the room")
expect_error(lk_publish_pcm(alice, tone), "left the room")

## --- end-to-end encryption: only the matching key decodes the tone ---
room <- new_room("livekitr-e2ee")
speaker <- join(room, "speaker", e2ee = "correct horse")
ears <- new.env()
listener <- function(identity, e2ee) {
    session <- join(room, identity, e2ee = e2ee)
    ears[[identity]] <- integer()
    lk_on_audio(session, function(pcm, info) {
        ears[[identity]] <- c(ears[[identity]], pcm)
    })
    session
}
same <- listener("same-key", "correct horse")
wrong <- listener("wrong-key", "battery staple")
sessions <- list(speaker, same, wrong)
lk_publish_pcm(speaker, integer())
poll_all(sessions, 1)
lk_publish_pcm(speaker, tone)
poll_all(sessions, 2.5)
expect_true(abs(peak_hz(ears[["same-key"]], rate) - 440) <= 2)
expect_true(sum(abs(ears[["same-key"]]) > 1000L) > 1.5 * rate)
## the wrong key gives silence, apart from a few milliseconds of noise
expect_true(sum(abs(ears[["wrong-key"]]) > 1000L) < rate %/% 10L)

## rotating the shared key on both ends keeps audio flowing
ears[["same-key"]] <- integer()
lk_set_e2ee_key(speaker, "second key")
lk_set_e2ee_key(same, "second key")
lk_publish_pcm(speaker, tone)
poll_all(sessions, 2)
expect_true(sum(abs(ears[["same-key"]]) > 1000L) > 1.5 * rate)
for (session in sessions) {
    lk_disconnect(session)
}

## --- per-participant keys, as MatrixRTC clients use them ---
## HKDF, a 256-slot key ring, a key set before the track exists, then a
## rotation to another index while publishing.
room <- new_room("livekitr-ppk")
e2ee <- list(kdf = "hkdf", key_ring_size = 256L)
speaker <- join(room, "speaker", e2ee = e2ee)
ears <- new.env()
same <- listener("same-key", e2ee)
wrong <- listener("wrong-key", e2ee)
sessions <- list(speaker, same, wrong)
key_one <- as.raw(1:16)
key_two <- as.raw(101:116)
lk_set_e2ee_key(speaker, key_one, identity = "speaker", key_index = 200L)
lk_set_e2ee_key(same, key_one, identity = "speaker", key_index = 200L)
lk_set_e2ee_key(wrong, as.raw(16:1), identity = "speaker", key_index = 200L)
lk_publish_pcm(speaker, integer())
poll_all(sessions, 1)
lk_publish_pcm(speaker, tone)
poll_all(sessions, 2.5)
expect_true(abs(peak_hz(ears[["same-key"]], rate) - 440) <= 2)
expect_true(sum(abs(ears[["same-key"]]) > 1000L) > 1.5 * rate)
expect_true(sum(abs(ears[["wrong-key"]]) > 1000L) < rate %/% 10L)

ears[["same-key"]] <- integer()
lk_set_e2ee_key(same, key_two, identity = "speaker", key_index = 201L)
lk_set_e2ee_key(speaker, key_two, identity = "speaker", key_index = 201L)
lk_publish_pcm(speaker, tone)
poll_all(sessions, 2)
expect_true(sum(abs(ears[["same-key"]]) > 1000L) > 1.5 * rate)
for (session in sessions) {
    lk_disconnect(session)
}

## keys need a session joined with e2ee
plain <- join(new_room("livekitr-plain"), "plain")
expect_error(lk_set_e2ee_key(plain, "key"), "joined without `e2ee`")
lk_disconnect(plain)

## --- a rejected token is an error, not a hang ---
expect_error(lk_connect(url, "not.a.token"), "could not join the room")
