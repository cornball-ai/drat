library(livekitr)

## No network here: the installer is exercised against a local archive
## through a file:// URL, which needs libcurl.
if (!capabilities("libcurl")) {
    exit_file("download.file() has no libcurl")
}

## one pinned checksum per published platform, and the URL they live at
assets <- livekitr:::ffi_assets
expect_equal(sort(names(assets)),
             c("linux-arm64", "linux-x86_64", "macos-arm64", "macos-x86_64",
               "windows-arm64", "windows-x86_64"))
expect_true(all(grepl("^[0-9a-f]{64}$", assets)))
expect_equal(livekitr:::ffi_asset_url("linux-x86_64"),
             paste0("https://github.com/livekit/rust-sdks/releases/download/",
                    "livekit-ffi/v0.12.81/ffi-linux-x86_64.zip"))
expect_true(startsWith(livekitr:::ffi_install_dir(),
                       tools::R_user_dir("livekitr", "data")))

## a fake release archive: the library file plus LiveKit's notices
lib_name <- livekitr:::ffi_lib_name()
work <- tempfile("livekitr-install-")
dir.create(file.path(work, "payload"), recursive = TRUE)
writeBin(as.raw(c(0x7f, 0x45, 0x4c, 0x46, 1:64)),
         file.path(work, "payload", lib_name))
writeLines("# livekit", file.path(work, "payload", "LICENSE.md"))
zip_path <- file.path(work, "ffi-test.zip")
old_wd <- setwd(file.path(work, "payload"))
status <- utils::zip(zip_path, c(lib_name, "LICENSE.md"), flags = "-q")
setwd(old_wd)
if (status != 0L || !file.exists(zip_path)) {
    unlink(work, recursive = TRUE)
    exit_file("no zip program available")
}
url <- paste0("file://", zip_path)
sha <- unname(tools::sha256sum(zip_path))
dest <- file.path(work, "installed")

local({
    old <- options(download.file.method = "libcurl")
    on.exit(options(old))

    ## a checksum mismatch installs nothing
    expect_error(livekitr:::ffi_install_from(url, strrep("0", 64L), dest,
                                             quiet = TRUE),
                 "does not match the expected checksum")
    expect_false(dir.exists(dest))

    ## the matching archive installs the library and the notices
    path <- livekitr:::ffi_install_from(url, sha, dest, quiet = TRUE)
    expect_equal(path, file.path(dest, lib_name))
    expect_true(file.exists(path))
    expect_equal(file.size(path), 68)
    expect_true(file.exists(file.path(dest, "LICENSE.md")))

    ## an archive without the library is refused
    other <- file.path(work, "other.zip")
    old_wd <- setwd(file.path(work, "payload"))
    utils::zip(other, "LICENSE.md", flags = "-q")
    setwd(old_wd)
    expect_error(livekitr:::ffi_install_from(paste0("file://", other),
                                             unname(tools::sha256sum(other)),
                                             file.path(work, "other"),
                                             quiet = TRUE),
                 "does not contain")

    ## lk_install_ffi() finds an existing install without downloading
    expect_message(found <- lk_install_ffi(dir = dest, ask = FALSE),
                   "already installed")
    expect_equal(found, path)
    expect_silent(lk_install_ffi(dir = dest, ask = FALSE, quiet = TRUE))
})
unlink(work, recursive = TRUE)
