library(livekitr)

b64url <- livekitr:::b64url
hmac_sha256 <- livekitr:::hmac_sha256

hex <- function(bytes) paste(as.character(bytes), collapse = "")

## Inverse of b64url, for reading tokens back.
b64url_decode <- function(x) {
    alphabet <- c(LETTERS, letters, 0:9, "-", "_")
    v <- match(strsplit(x, "")[[1L]], alphabet) - 1L
    bits <- as.vector(vapply(v, function(s) rev(as.integer(intToBits(s))[1:6]),
                             integer(6L)))
    bits <- bits[seq_len(length(bits) %/% 8L * 8L)]
    as.raw(colSums(matrix(bits, nrow = 8L) * 2L^(7:0)))
}

## base64url, RFC 4648 section 10 vectors without padding
expect_equal(b64url(raw()), "")
expect_equal(b64url(charToRaw("f")), "Zg")
expect_equal(b64url(charToRaw("fo")), "Zm8")
expect_equal(b64url(charToRaw("foo")), "Zm9v")
expect_equal(b64url(charToRaw("foob")), "Zm9vYg")
expect_equal(b64url(charToRaw("fooba")), "Zm9vYmE")
expect_equal(b64url(charToRaw("foobar")), "Zm9vYmFy")
## the URL-safe alphabet: 0xfb 0xff is "+/8" in plain base64
expect_equal(b64url(as.raw(c(0xfb, 0xff))), "-_8")
expect_equal(b64url_decode(b64url(as.raw(0:255))), as.raw(0:255))

## HMAC-SHA256, RFC 4231 test cases 1, 2 and 6
expect_equal(hex(hmac_sha256(as.raw(rep(0x0b, 20L)), charToRaw("Hi There"))),
    "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7")
expect_equal(hex(hmac_sha256(charToRaw("Jefe"),
                             charToRaw("what do ya want for nothing?"))),
    "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843")
expect_equal(hex(hmac_sha256(as.raw(rep(0xaa, 131L)),
    charToRaw("Test Using Larger Than Block-Size Key - Hash Key First"))),
    "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54")

## the jwt.io HS256 reference token
signing_input <- paste0("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.",
    "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ")
expect_equal(b64url(hmac_sha256(charToRaw("your-256-bit-secret"),
                                charToRaw(signing_input))),
             "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")

## JSON claim encoding
expect_equal(livekitr:::json_object(list(a = "x\"y\\z", b = TRUE, c = 12,
                                         d = list(e = FALSE))),
             "{\"a\":\"x\\\"y\\\\z\",\"b\":true,\"c\":12,\"d\":{\"e\":false}}")
expect_equal(livekitr:::json_object(list(n = "line\nbreak")),
             "{\"n\":\"line\\u000abreak\"}")
expect_error(livekitr:::json_object(list(a = c(1, 2))), "single")

## a minted token: three parts, expected claims, verifiable signature
token <- lk_mint_token("devkey", "secret", room = "demo", identity = "alice",
                       name = "Alice", ttl = 600,
                       grants = list(canPublish = FALSE))
parts <- strsplit(token, ".", fixed = TRUE)[[1L]]
expect_equal(length(parts), 3L)
expect_equal(rawToChar(b64url_decode(parts[1L])),
             "{\"alg\":\"HS256\",\"typ\":\"JWT\"}")
claims <- rawToChar(b64url_decode(parts[2L]))
expect_true(grepl("\"iss\":\"devkey\"", claims, fixed = TRUE))
expect_true(grepl("\"sub\":\"alice\"", claims, fixed = TRUE))
expect_true(grepl("\"name\":\"Alice\"", claims, fixed = TRUE))
expect_true(grepl(
    "\"video\":{\"room\":\"demo\",\"roomJoin\":true,\"canPublish\":false}",
    claims, fixed = TRUE))
nbf <- as.numeric(sub(".*\"nbf\":([0-9]+).*", "\\1", claims))
exp <- as.numeric(sub(".*\"exp\":([0-9]+).*", "\\1", claims))
expect_equal(exp - nbf, 600)
expect_true(abs(nbf - as.numeric(Sys.time())) < 60)
expect_equal(parts[3L],
             b64url(hmac_sha256(charToRaw("secret"),
                                charToRaw(paste(parts[1:2], collapse = ".")))))
expect_error(lk_mint_token("devkey", "secret", room = c("a", "b"),
                           identity = "alice"))
