## Receiving audio. Each subscribed remote audio track gets a native
## audio stream; livekit-ffi decodes and resamples, and delivers int16
## frames that route_audio() copies into the session.

stream_open <- function(session, sid) {
    track <- session$tracks[[sid]]
    if (is.null(track) || track$kind != "KIND_AUDIO" ||
        !is.null(track$stream)) {
        return(invisible(NULL))
    }
    format <- session$audio_format
    response <- ffi_call("new_audio_stream",
                         pb("NewAudioStreamRequest", track_handle = track$handle, type = 0L,
                            sample_rate = format$sample_rate, num_channels = format$channels,
                            frame_size_ms = format$frame_ms))
    handle <- response$stream$handle$id
    session$tracks[[sid]]$stream <- handle
    .lk$streams[[id_key(handle)]] <- list(session = session, track_sid = sid,
        identity = track$identity)
    invisible(NULL)
}

stream_close <- function(session, sid) {
    handle <- session$tracks[[sid]]$stream
    if (!is.null(handle)) {
        rm(list = id_key(handle), envir = .lk$streams)
        ffi_drop(handle)
        session$tracks[[sid]]$stream <- NULL
    }
    invisible(NULL)
}

## Stop receiving a track. livekit-ffi releases every track handle itself
## when the room closes and warns if one is already gone, so the handle
## is kept for lk_disconnect() to drop afterwards.
track_close <- function(session, sid) {
    track <- session$tracks[[sid]]
    if (!is.null(track)) {
        stream_close(session, sid)
        session$handles <- c(session$handles, track$handle)
        session$tracks[[sid]] <- NULL
    }
    invisible(NULL)
}

#' Receive audio from the room
#'
#' Registers a function to receive the audio of every remote participant.
#' LiveKit delivers one track per participant, so each call of
#' \code{callback} carries the audio of a single speaker. The callback
#' runs on the R main thread, and only inside \code{\link{lk_poll}}.
#'
#' @param session A session from \code{\link{lk_connect}}.
#' @param callback A function \code{function(pcm, info)}, or \code{NULL}
#'   to stop receiving. \code{pcm} is an integer vector of 16-bit samples
#'   (interleaved when there is more than one channel) holding everything
#'   received from one track since the last poll. \code{info} is a list
#'   with \code{identity} (the participant), \code{track_sid},
#'   \code{sample_rate} and \code{channels}.
#' @param sample_rate Sample rate to deliver, in Hz. Audio is resampled
#'   natively.
#' @param channels Number of channels to deliver.
#' @param frame_ms Length of the native frames, in milliseconds. Larger
#'   frames mean fewer events to process per second.
#' @return \code{session}, invisibly.
#' @examples
#' \dontrun{
#' lk_on_audio(session, function(pcm, info) {
#'     cat(info$identity, ":", length(pcm), "samples\n")
#' })
#' lk_poll(session, timeout = 1)
#' }
#' @export
lk_on_audio <- function(session, callback, sample_rate = 48000L,
                        channels = 1L, frame_ms = 20L) {
    session_check(session)
    stopifnot(is.null(callback) || is.function(callback))
    ## Streams carry the format they were opened with; reopen them all.
    for (sid in names(session$tracks)) {
        stream_close(session, sid)
    }
    session$on_audio <- callback
    if (is.null(callback)) {
        session$audio <- list()
        return(invisible(session))
    }
    session$audio_format <- list(sample_rate = as.integer(sample_rate),
                                 channels = as.integer(channels),
                                 frame_ms = as.integer(frame_ms))
    for (sid in names(session$tracks)) {
        stream_open(session, sid)
    }
    invisible(session)
}

## Hand queued audio to the callback: one call per track, frames joined
## in arrival order.
audio_deliver <- function(session) {
    frames <- session$audio
    session$audio <- list()
    callback <- session$on_audio
    if (length(frames) == 0L || is.null(callback)) {
        return(invisible(NULL))
    }
    sids <- vapply(frames, function(frame) frame$track_sid, "")
    for (sid in unique(sids)) {
        mine <- frames[sids == sid]
        pcm <- unlist(lapply(mine, function(frame) frame$pcm),
                      use.names = FALSE)
        callback(pcm, list(identity = mine[[1L]]$identity, track_sid = sid,
                           sample_rate = session$audio_format$sample_rate,
                           channels = session$audio_format$channels))
    }
    invisible(NULL)
}
