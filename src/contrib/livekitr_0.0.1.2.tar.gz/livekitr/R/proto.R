## The livekit-ffi protobuf schemas (inst/proto, package livekit.proto),
## loaded into RProtoBuf's descriptor pool at runtime.

proto_load <- function() {
    if (isTRUE(.lk$proto)) {
        return(invisible(NULL))
    }
    ## ffi.proto imports the other schema files.
    RProtoBuf::readProtoFiles2("ffi.proto",
                               protoPath = system.file("proto", package = "livekitr"))
    .lk$response_type <- proto_type("FfiResponse")
    .lk$event_type <- proto_type("FfiEvent")
    .lk$room_members <- setdiff(proto_fields("RoomEvent"), "room_handle")
    .lk$proto <- TRUE
    invisible(NULL)
}

proto_type <- function(type) {
    RProtoBuf::P(paste0("livekit.proto.", type))
}

## Build a livekit.proto message from field values. The first argument
## is named so that it cannot collide with a field called `type`.
pb <- function(.message, ...) {
    RProtoBuf::new(proto_type(.message), ...)
}

proto_fields <- function(type) {
    descriptor <- proto_type(type)
    vapply(seq_len(descriptor$field_count()), function(i) {
        descriptor$field(i)$name()
    }, "")
}

## Name of an enum value, e.g. enum_name("TrackKind", 1L) is "KIND_AUDIO".
enum_name <- function(type, number) {
    proto_type(type)$value(number = number)$name()
}

## Which member of a oneof is set, or NA.
which_member <- function(message, members) {
    for (member in members) {
        if (message$has(member)) {
            return(member)
        }
    }
    NA_character_
}

## Handles and async ids are uint64 on the wire; RProtoBuf returns them as
## doubles (or strings under options(RProtoBuf.int64AsString = TRUE)).
## Table keys are their decimal text.
id_key <- function(id) {
    sprintf("%.0f", as.numeric(id))
}
