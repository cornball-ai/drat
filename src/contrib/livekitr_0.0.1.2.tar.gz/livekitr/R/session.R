## A session is the R side of one joined room: its native handles, the
## events and audio queued for lk_poll(), and the publish state.

session_new <- function(url, result) {
    session <- new.env(parent = emptyenv())
    room <- result$room
    local <- result$local_participant
    session$url <- url
    session$room <- room$info$name
    session$identity <- local$info$identity
    session$room_handle <- room$handle$id
    session$local_handle <- local$handle$id
    ## Handles to release on disconnect, besides the room's own.
    session$handles <- local$handle$id
    session$participants <- list()
    session$tracks <- list()
    session$events <- list()
    session$audio <- list()
    session$on_audio <- NULL
    session$audio_format <- NULL
    session$publish <- NULL
    session$connected <- TRUE
    session$closed <- FALSE
    for (entry in result$participants) {
        info <- entry$participant$info
        session$handles <- c(session$handles, entry$participant$handle$id)
        session$participants[[info$identity]] <- list(sid = info$sid,
            name = info$name)
        for (publication in entry$publications) {
            session$handles <- c(session$handles, publication$handle$id)
        }
    }
    class(session) <- "lk_session"
    session
}

session_check <- function(session) {
    if (!inherits(session, "lk_session")) {
        stop("`session` must come from lk_connect()", call. = FALSE)
    }
    if (isTRUE(session$closed)) {
        stop("this session has left the room", call. = FALSE)
    }
    invisible(NULL)
}

#' Print a LiveKit session
#'
#' @param x A session from \code{\link{lk_connect}}.
#' @param ... Ignored.
#' @return \code{x}, invisibly.
#' @export
print.lk_session <- function(x, ...) {
    state <- if (isTRUE(x$closed)) {
        "left"
    } else if (isTRUE(x$connected)) {
        "connected"
    } else {
        "disconnected"
    }
    cat("<lk_session> room '", x$room, "' as '", x$identity, "' (", state,
        ")\n", sep = "")
    cat("  participants: ", length(x$participants), ", subscribed tracks: ",
        length(x$tracks), "\n", sep = "")
    invisible(x)
}
