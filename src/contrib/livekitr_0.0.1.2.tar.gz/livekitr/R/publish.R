## Publishing audio: an audio source feeds a local track, which is
## published to the room once and then fed PCM.

publish_start <- function(session, sample_rate, channels, timeout) {
    source <- ffi_call("new_audio_source",
                       pb("NewAudioSourceRequest", type = 0L, sample_rate = sample_rate,
                          num_channels = channels, queue_size_ms = 1000L))
    source_handle <- source$source$handle$id
    track <- ffi_call("create_audio_track",
                      pb("CreateAudioTrackRequest", name = "audio",
                         source_handle = source_handle))
    track_handle <- track$track$handle$id
    ## TrackSource SOURCE_MICROPHONE = 2.
    response <- ffi_call("publish_track",
                         pb("PublishTrackRequest",
                            local_participant_handle = session$local_handle,
                            track_handle = track_handle,
                            options = pb("TrackPublishOptions", source = 2L)))
    callback <- tryCatch(
                         await(response$async_id, timeout, "publishing the audio track"),
                         error = function(e) e)
    if (inherits(callback, "error") || callback$has("error")) {
        ffi_drop(track_handle)
        ffi_drop(source_handle)
        reason <- if (inherits(callback, "error")) {
            conditionMessage(callback)
        } else {
            callback$error
        }
        stop("could not publish audio: ", reason, call. = FALSE)
    }
    session$publish <- list(source = source_handle, track = track_handle,
                            publication = callback$publication$handle$id,
                            track_sid = callback$publication$info$sid,
                            sample_rate = sample_rate, channels = channels)
    e2ee_use_index(session)
    invisible(NULL)
}

## Samples as native-endian int16 bytes.
pcm_bytes <- function(samples) {
    if (is.raw(samples)) {
        if (length(samples) %% 2L != 0L) {
            stop("raw `samples` must hold whole 16-bit samples", call. = FALSE)
        }
        return(samples)
    }
    if (!is.integer(samples)) {
        stop("`samples` must be an integer vector of 16-bit samples or a ",
             "raw vector of int16 bytes", call. = FALSE)
    }
    if (anyNA(samples) || any(samples > 32767L) || any(samples < -32768L)) {
        stop("`samples` must lie between -32768 and 32767", call. = FALSE)
    }
    writeBin(samples, raw(), size = 2L)
}

#' Publish audio to the room
#'
#' Sends 16-bit PCM to the room as this participant's microphone track.
#' The first call publishes the track; later calls must use the same
#' sample rate and channel count. Audio is played out in real time, so a
#' call with \code{wait = TRUE} returns about when the last sample has
#' been handed to the encoder, minus up to one second of native buffer.
#'
#' @param session A session from \code{\link{lk_connect}}.
#' @param samples An integer vector of samples in -32768..32767
#'   (interleaved when there is more than one channel), or a raw vector
#'   of native-endian int16 bytes.
#' @param sample_rate Sample rate of \code{samples}, in Hz.
#' @param channels Number of channels in \code{samples}.
#' @param wait Wait until the samples have been accepted for playout? With
#'   \code{FALSE} the call returns at once and a capture failure is
#'   reported as a warning from a later \code{\link{lk_poll}}.
#' @return \code{session}, invisibly.
#' @examples
#' \dontrun{
#' tone <- as.integer(8000 * sin(2 * pi * 440 * seq_len(48000) / 48000))
#' lk_publish_pcm(session, tone)
#' }
#' @export
lk_publish_pcm <- function(session, samples, sample_rate = 48000L,
                           channels = 1L, wait = TRUE) {
    session_check(session)
    sample_rate <- as.integer(sample_rate)
    channels <- as.integer(channels)
    bytes <- pcm_bytes(samples)
    n_samples <- length(bytes) %/% 2L
    if (n_samples %% channels != 0L) {
        stop("`samples` does not divide into ", channels, " channels",
             call. = FALSE)
    }
    if (is.null(session$publish)) {
        publish_start(session, sample_rate, channels, timeout = 15)
    }
    published <- session$publish
    if (published$sample_rate != sample_rate ||
        published$channels != channels) {
        stop("the published track is ", published$sample_rate, " Hz with ",
             published$channels, " channel(s); got ", sample_rate, " Hz with ",
             channels, call. = FALSE)
    }
    if (n_samples == 0L) {
        return(invisible(session))
    }
    ## livekit-ffi copies the samples during the request, so `bytes` only
    ## has to stay alive until ffi_call() returns.
    buffer <- pb("AudioFrameBufferInfo",
                 data_ptr = .Call(livekitr_address, bytes),
                 num_channels = channels, sample_rate = sample_rate,
                 samples_per_channel = n_samples %/% channels)
    response <- ffi_call("capture_audio_frame",
                         pb("CaptureAudioFrameRequest",
                            source_handle = published$source,
                            buffer = buffer))
    if (!wait) {
        ignore_async(response$async_id)
        return(invisible(session))
    }
    seconds <- n_samples / channels / sample_rate
    callback <- await(response$async_id, seconds + 15, "publishing audio")
    if (callback$has("error")) {
        stop("could not publish audio: ", callback$error, call. = FALSE)
    }
    invisible(session)
}
