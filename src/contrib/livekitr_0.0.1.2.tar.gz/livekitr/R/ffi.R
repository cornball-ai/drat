## Locating, loading and starting the livekit-ffi library.

## The livekit-ffi release this package's bundled schemas come from.
ffi_version <- "0.12.81"

ffi_symbols <- c("livekit_ffi_initialize", "livekit_ffi_request",
                 "livekit_ffi_drop_handle", "livekit_ffi_dispose")

## Platform directory name, matching livekit-ffi's release assets
## (ffi-linux-x86_64.zip and so on). NA where no build exists.
ffi_platform <- function() {
    info <- Sys.info()
    os <- switch(info[["sysname"]], Linux = "linux", Darwin = "macos",
                 Windows = "windows", NA_character_)
    arch <- switch(info[["machine"]], x86_64 =, amd64 =,
                   "x86-64" = "x86_64", aarch64 =, arm64 = "arm64",
                   NA_character_)
    if (is.na(os) || is.na(arch)) {
        return(NA_character_)
    }
    paste(os, arch, sep = "-")
}

ffi_lib_name <- function() {
    switch(Sys.info()[["sysname"]], Darwin = "liblivekit_ffi.dylib",
           Windows = "livekit_ffi.dll", "liblivekit_ffi.so")
}

## Directories searched for the library after LIVEKIT_FFI_LIB: the one
## lk_install_ffi() writes to, then the usual system library directories.
ffi_search_dirs <- function() {
    c(ffi_install_dir(), "/usr/local/lib", "/usr/local/lib64",
      "/opt/homebrew/lib", "/usr/lib", "/usr/lib64")
}

## Path of the library to load. LIVEKIT_FFI_LIB is returned as given, so
## a wrong value shows up in the error; otherwise the first existing
## candidate, or "" when there is none.
ffi_path <- function() {
    path <- Sys.getenv("LIVEKIT_FFI_LIB", "")
    if (nzchar(path)) {
        return(path)
    }
    if (is.na(ffi_platform())) {
        return("")
    }
    candidates <- file.path(ffi_search_dirs(), ffi_lib_name())
    found <- candidates[file.exists(candidates)]
    if (length(found) == 0L) "" else found[[1L]]
}

## Load the library once and resolve its entry points. Loading starts no
## threads; ffi_start() does that.
ffi_load <- function() {
    if (!is.null(.lk$symbols)) {
        return(invisible(NULL))
    }
    path <- ffi_path()
    if (!nzchar(path) || !file.exists(path)) {
        stop("no livekit-ffi library found; run lk_install_ffi(), or set ",
             "LIVEKIT_FFI_LIB to the path of one (see ?livekit_available)",
             call. = FALSE)
    }
    dll <- dyn.load(path, local = TRUE, now = TRUE)
    symbols <- lapply(ffi_symbols, function(name) {
        getNativeSymbolInfo(name, dll)$address
    })
    names(symbols) <- ffi_symbols
    .lk$path <- path
    .lk$symbols <- symbols
    invisible(NULL)
}

#' Is the livekit-ffi library available?
#'
#' The package installs on any platform, but joining a room needs the
#' prebuilt \code{livekit-ffi} shared library, which is not part of the
#' package. It is looked up, in order: at the path in the environment
#' variable \code{LIVEKIT_FFI_LIB} when set; in the directory
#' \code{\link{lk_install_ffi}} downloads it to; then in the usual system
#' library directories (\code{/usr/local/lib} and the like).
#' \code{\link{lk_mint_token}} works without it.
#'
#' @return \code{TRUE} if the library was found and loaded, \code{FALSE}
#'   otherwise.
#' @examples
#' livekit_available()
#' @export
livekit_available <- function() {
    tryCatch({
        ffi_load()
        TRUE
    }, error = function(e) FALSE)
}

## Start livekit-ffi's runtime once per process. Its threads do not
## survive fork(), so a forked child must not reuse the parent's state.
ffi_start <- function() {
    if (isTRUE(.lk$started)) {
        if (!identical(.lk$pid, Sys.getpid())) {
            stop("livekit-ffi was started in another process; a forked ",
                 "child cannot use the parent's LiveKit sessions",
                 call. = FALSE)
        }
        if (!is.null(.lk$panic)) {
            stop("livekit-ffi panicked earlier in this session: ",
                 .lk$panic, call. = FALSE)
        }
        return(invisible(NULL))
    }
    ffi_load()
    proto_load()
    .lk$async <- new.env(parent = emptyenv())
    .lk$ignored <- new.env(parent = emptyenv())
    .lk$rooms <- new.env(parent = emptyenv())
    .lk$streams <- new.env(parent = emptyenv())
    .lk$panic <- NULL
    .lk$log_threshold <- NULL
    log_sync()
    .Call(livekitr_start, .lk$symbols[["livekit_ffi_initialize"]],
          .lk$symbols[["livekit_ffi_request"]],
          .lk$symbols[["livekit_ffi_drop_handle"]],
          .lk$symbols[["livekit_ffi_dispose"]], ffi_version)
    .lk$pid <- Sys.getpid()
    .lk$started <- TRUE
    invisible(NULL)
}

## Close every room and stop the runtime. Only the process that started
## livekit-ffi owns its threads.
ffi_stop <- function() {
    if (isTRUE(.lk$started) && identical(.lk$pid, Sys.getpid())) {
        .Call(livekitr_dispose)
    }
    .lk$started <- FALSE
    invisible(NULL)
}

## Send one FfiRequest member and return the matching FfiResponse member.
ffi_call <- function(member, message) {
    ffi_start()
    request <- pb("FfiRequest")
    request[[member]] <- message
    bytes <- .Call(livekitr_request, RProtoBuf::serialize(request, NULL))
    response <- RProtoBuf::read(.lk$response_type, bytes)
    response[[member]]
}

## Release a handle livekit-ffi handed to us.
ffi_drop <- function(handle) {
    if (isTRUE(.lk$started) && length(handle) == 1L) {
        .Call(livekitr_drop_handle, as.numeric(handle))
    }
    invisible(NULL)
}
