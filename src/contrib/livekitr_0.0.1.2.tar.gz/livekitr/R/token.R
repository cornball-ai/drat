## Access tokens: an HS256-signed JWT, built with base R so that minting
## works without the native library.

b64url <- function(bytes) {
    n <- length(bytes)
    if (n == 0L) {
        return("")
    }
    alphabet <- c(LETTERS, letters, 0:9, "-", "_")
    pad <- (3L - n %% 3L) %% 3L
    m <- matrix(as.integer(c(bytes, raw(pad))), nrow = 3L)
    sextets <- rbind(m[1L,] %/% 4L, (m[1L,] %% 4L) * 16L + m[2L,] %/% 16L,
                     (m[2L,] %% 16L) * 4L + m[3L,] %/% 64L, m[3L,] %% 64L)
    out <- alphabet[sextets + 1L]
    paste(out[seq_len(length(out) - pad)], collapse = "")
}

sha256 <- function(bytes) {
    hex <- tools::sha256sum(bytes = bytes)
    as.raw(strtoi(substring(hex, seq(1L, 63L, 2L), seq(2L, 64L, 2L)), 16L))
}

hmac_sha256 <- function(key, message) {
    if (length(key) > 64L) {
        key <- sha256(key)
    }
    key <- as.integer(c(key, raw(64L - length(key))))
    inner <- sha256(c(as.raw(bitwXor(key, 0x36L)), message))
    sha256(c(as.raw(bitwXor(key, 0x5cL)), inner))
}

json_string <- function(x) {
    x <- gsub("\\", "\\\\", x, fixed = TRUE)
    x <- gsub("\"", "\\\"", x, fixed = TRUE)
    for (code in 1:31) {
        x <- gsub(rawToChar(as.raw(code)), sprintf("\\u%04x", code), x,
                  fixed = TRUE)
    }
    paste0("\"", x, "\"")
}

## JSON for the claim set: named lists of strings, numbers, logicals and
## further named lists.
json_object <- function(x) {
    fields <- vapply(names(x), function(name) {
        value <- x[[name]]
        encoded <- if (is.list(value)) {
            json_object(value)
        } else if (length(value) != 1L || is.na(value)) {
            stop("claim '", name, "' must be a single non-missing value",
                 call. = FALSE)
        } else if (is.logical(value)) {
            if (value) "true" else "false"
        } else if (is.numeric(value)) {
            format(value, scientific = FALSE, trim = TRUE)
        } else {
            json_string(enc2utf8(as.character(value)))
        }
        paste0(json_string(name), ":", encoded)
    }, "")
    paste0("{", paste(fields, collapse = ","), "}")
}

#' Mint a LiveKit access token
#'
#' Signs a JSON Web Token (HS256) that lets one participant join one
#' room. The token is created locally from the server's API key and
#' secret; no request is made. This function does not need the
#' \code{livekit-ffi} library.
#'
#' @param api_key API key of the LiveKit server.
#' @param api_secret API secret paired with \code{api_key}.
#' @param room Name of the room the token grants access to.
#' @param identity Identity of the participant; unique within the room.
#' @param name Display name of the participant, or \code{NULL}.
#' @param ttl Lifetime of the token, in seconds.
#' @param grants Named list of further video grants, which also override
#'   the defaults (\code{roomJoin = TRUE}), for example
#'   \code{list(canPublish = FALSE)}.
#' @return The token, a string.
#' @examples
#' lk_mint_token("devkey", "secret", room = "demo", identity = "r-agent")
#' @export
lk_mint_token <- function(api_key, api_secret, room, identity, name = NULL,
                          ttl = 3600, grants = list()) {
    stopifnot(is.character(api_key), length(api_key) == 1L,
              is.character(api_secret), length(api_secret) == 1L,
              is.character(room), length(room) == 1L, is.character(identity),
              length(identity) == 1L, is.numeric(ttl), length(ttl) == 1L,
              is.list(grants))
    now <- floor(as.numeric(Sys.time()))
    video <- utils::modifyList(list(room = room, roomJoin = TRUE), grants)
    claims <- list(iss = api_key, sub = identity, nbf = now, exp = now + ttl,
                   video = video)
    if (!is.null(name)) {
        claims$name <- name
    }
    signing_input <- paste(
                           b64url(charToRaw("{\"alg\":\"HS256\",\"typ\":\"JWT\"}")),
                           b64url(charToRaw(json_object(claims))), sep = ".")
    signature <- hmac_sha256(charToRaw(enc2utf8(api_secret)),
                             charToRaw(signing_input))
    paste(signing_input, b64url(signature), sep = ".")
}
