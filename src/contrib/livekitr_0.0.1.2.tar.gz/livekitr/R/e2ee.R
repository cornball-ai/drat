## End-to-end encryption. The frame key is supplied from R; livekit-ffi
## derives the per-frame keys and does the encryption.

key_bytes <- function(key) {
    if (is.character(key) && length(key) == 1L && !is.na(key)) {
        return(charToRaw(key))
    }
    if (is.raw(key) && length(key) > 0L) {
        return(key)
    }
    stop("an encryption key must be a string or a non-empty raw vector",
         call. = FALSE)
}

## E2eeOptions for lk_connect(). The defaults are livekit's own
## (livekit/src/room/e2ee/key_provider.rs).
e2ee_options <- function(e2ee) {
    if (!is.list(e2ee)) {
        e2ee <- list(shared_key = e2ee)
    }
    known <- c("shared_key", "ratchet_salt", "ratchet_window_size",
               "failure_tolerance", "key_ring_size", "kdf")
    unknown <- setdiff(names(e2ee), known)
    if (length(unknown) > 0L) {
        stop("unknown e2ee option(s): ", paste(unknown, collapse = ", "),
             call. = FALSE)
    }
    kdf <- match.arg(e2ee$kdf %||% "pbkdf2", c("pbkdf2", "hkdf"))
    provider <- pb("KeyProviderOptions",
                   ratchet_window_size = as.integer(e2ee$ratchet_window_size %||% 16L),
                   ratchet_salt = key_bytes(e2ee$ratchet_salt %||% "LKFrameEncryptionKey"),
                   failure_tolerance = as.integer(e2ee$failure_tolerance %||% -1L),
                   key_ring_size = as.integer(e2ee$key_ring_size %||% 16L),
                   ## KeyDerivationFunction PBKDF2 = 0, HKDF = 1.
                   key_derivation_function = if (kdf == "hkdf") 1L else 0L)
    if (!is.null(e2ee$shared_key)) {
        provider$shared_key <- key_bytes(e2ee$shared_key)
    }
    ## EncryptionType GCM = 1.
    pb("E2eeOptions", encryption_type = 1L, key_provider_options = provider)
}

#' Set an end-to-end encryption key
#'
#' Sets or rotates a media encryption key on a session that was joined
#' with \code{e2ee} enabled (see \code{\link{lk_connect}}). Without
#' \code{identity} the key is the room's shared key; with it, the key
#' applies to that one participant's media.
#'
#' Received media names the key index it was encrypted with, so keys of
#' other participants only need to be set. Setting the shared key, or the
#' key of this session's own identity, also makes this session encrypt
#' with that index from then on.
#'
#' @param session A session from \code{\link{lk_connect}}.
#' @param key The key: a string or a raw vector.
#' @param identity Participant identity the key belongs to, or
#'   \code{NULL} for the shared key.
#' @param key_index Index of the key in the key ring, from 0 to the
#'   \code{key_ring_size} the session was joined with, minus 1.
#' @return \code{session}, invisibly.
#' @export
lk_set_e2ee_key <- function(session, key, identity = NULL, key_index = 0L) {
    session_check(session)
    if (!isTRUE(session$e2ee)) {
        stop("this session was joined without `e2ee`", call. = FALSE)
    }
    key <- key_bytes(key)
    key_index <- as.integer(key_index)
    stopifnot(length(key_index) == 1L, !is.na(key_index), key_index >= 0L)
    request <- pb("E2eeRequest", room_handle = session$room_handle)
    if (is.null(identity)) {
        request$set_shared_key <- pb("SetSharedKeyRequest", shared_key = key,
                                     key_index = key_index)
    } else {
        stopifnot(is.character(identity), length(identity) == 1L)
        request$set_key <- pb("SetKeyRequest",
                              participant_identity = identity, key = key,
                              key_index = key_index)
    }
    ffi_call("e2ee", request)
    if (is.null(identity) || identical(identity, session$identity)) {
        session$key_index <- key_index
        e2ee_use_index(session)
    }
    invisible(session)
}

## Point the sender at the session's current key index. livekit-ffi
## encrypts a published track with index 0 until told otherwise, whatever
## index the key was stored under, and the frame cryptor only exists once
## the track is published; publish_start() calls this again.
e2ee_use_index <- function(session) {
    if (is.null(session$key_index) || is.null(session$publish)) {
        return(invisible(NULL))
    }
    request <- pb("E2eeRequest", room_handle = session$room_handle)
    request$cryptor_set_key_index <- pb("FrameCryptorSetKeyIndexRequest",
        participant_identity = session$identity,
        track_sid = session$publish$track_sid,
        key_index = session$key_index)
    ffi_call("e2ee", request)
    invisible(NULL)
}
