## Installing the livekit-ffi library into the user's data directory.
## Nothing here runs at install, load or check time: the download is an
## explicit action, as CRAN requires for precompiled software.

## sha256 of each livekit-ffi release asset, as published by GitHub's
## release API for livekit-ffi/v0.12.81. A download that does not match
## is refused.
ffi_assets <- c(
    "linux-x86_64" = "a80edd2078b7705b651ebd6899d102a0152523b678b5fa8ddd22c1696fe42c81",
    "linux-arm64" = "9a94a144f546cf0780a3a827b08ab976e87b8414c76c8c69ed571a39103061a9",
    "macos-arm64" = "44c025b6c3aa61f35aa2b55f30a8d3803e54119b66b466d970e13d46e167b73b",
    "macos-x86_64" = "1037c1ceb6f9bc6ad819f3ea1d4fb4c0dab4186e31005cd6c427f679aef71291",
    "windows-x86_64" = "c242f1cde2c6ace38d3a12919e4b3ea49ef2f67fbf5d0a5bd3ad2b10be1f1086",
    "windows-arm64" = "0ac003a5e6ebe6701109eb9cdb29e43b5dfdfa40acaa266a663f0e92ac3c0a7c")

ffi_asset_url <- function(platform, version = ffi_version) {
    sprintf(paste0("https://github.com/livekit/rust-sdks/releases/download/",
                   "livekit-ffi/v%s/ffi-%s.zip"), version, platform)
}

## Where lk_install_ffi() puts the library: one directory per version and
## platform under the package's user data directory.
ffi_install_dir <- function(version = ffi_version) {
    file.path(tools::R_user_dir("livekitr", "data"), version, ffi_platform())
}

## Download a release zip, check it against `sha256`, and unpack the
## library and LiveKit's notice file into `dir`. Returns the library path.
ffi_install_from <- function(url, sha256, dir, quiet = FALSE) {
    zip <- tempfile("livekit-ffi-", fileext = ".zip")
    on.exit(unlink(zip), add = TRUE)
    old <- options(timeout = max(600, getOption("timeout", 60)))
    on.exit(options(old), add = TRUE)
    status <- utils::download.file(url, zip, mode = "wb", quiet = quiet)
    if (status != 0L) {
        stop("download of ", url, " failed", call. = FALSE)
    }
    actual <- unname(tools::sha256sum(zip))
    if (!identical(actual, sha256)) {
        stop("the downloaded file does not match the expected checksum\n",
             "  expected: ", sha256, "\n  got:      ", actual,
             call. = FALSE)
    }
    staging <- tempfile("livekit-ffi-")
    on.exit(unlink(staging, recursive = TRUE), add = TRUE)
    files <- utils::unzip(zip, exdir = staging)
    library <- files[basename(files) == ffi_lib_name()]
    if (length(library) != 1L) {
        stop("the archive does not contain ", ffi_lib_name(), call. = FALSE)
    }
    dir.create(dir, recursive = TRUE, showWarnings = FALSE)
    notices <- files[basename(files) == "LICENSE.md"]
    if (!all(file.copy(c(library, notices), dir, overwrite = TRUE))) {
        stop("could not write to ", dir, call. = FALSE)
    }
    file.path(dir, ffi_lib_name())
}

#' Download the livekit-ffi library
#'
#' Fetches the prebuilt \code{livekit-ffi} library for this platform from
#' LiveKit's GitHub releases (about 10 MB), checks it against the sha256
#' recorded in the package, and unpacks it into a directory of the user's
#' R data area (\code{tools::R_user_dir("livekitr", "data")}), together
#' with LiveKit's third-party notice file. The package then finds it
#' without further configuration; see \code{\link{livekit_available}} for
#' the lookup order.
#'
#' The download happens only when this function is called. It is never
#' run on installing or loading the package.
#'
#' @param dir Directory to unpack into. The default keeps one directory
#'   per library version and platform.
#' @param ask Ask for confirmation before downloading? The default asks
#'   in interactive sessions only.
#' @param quiet Suppress the download progress output?
#' @return The path of the installed library, invisibly; \code{NULL} if
#'   the download was declined.
#' @examples
#' \dontrun{
#' lk_install_ffi()
#' livekit_available()
#' }
#' @export
lk_install_ffi <- function(dir = ffi_install_dir(), ask = interactive(),
                           quiet = FALSE) {
    platform <- ffi_platform()
    if (is.na(platform) || !platform %in% names(ffi_assets)) {
        stop("LiveKit publishes no prebuilt livekit-ffi ", ffi_version,
             " for this platform (", Sys.info()[["sysname"]], " ",
             Sys.info()[["machine"]], "); build it from ",
             "https://github.com/livekit/rust-sdks and set LIVEKIT_FFI_LIB",
             call. = FALSE)
    }
    path <- file.path(dir, ffi_lib_name())
    if (file.exists(path)) {
        if (!quiet) {
            message("livekit-ffi ", ffi_version, " is already installed at ",
                    path)
        }
        return(invisible(path))
    }
    url <- ffi_asset_url(platform)
    if (ask) {
        answer <- utils::askYesNo(paste0("Download livekit-ffi ", ffi_version,
                                         " for ", platform, " (about 10 MB) from ",
                                         url, " into ", dir, "?"))
        if (!isTRUE(answer)) {
            message("livekit-ffi was not installed")
            return(invisible(NULL))
        }
    }
    path <- ffi_install_from(url, ffi_assets[[platform]], dir, quiet = quiet)
    if (!quiet) {
        message("installed livekit-ffi ", ffi_version, " at ", path)
    }
    invisible(path)
}
