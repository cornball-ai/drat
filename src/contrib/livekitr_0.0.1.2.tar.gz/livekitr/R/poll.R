#' Collect room events and deliver received audio
#'
#' Drains the events livekit-ffi has queued since the last call. Audio
#' received meanwhile is passed to the callback registered with
#' \code{\link{lk_on_audio}}; room events are returned. Call this from the
#' program's own event loop: nothing is delivered between polls.
#'
#' Log messages from the native library are also shown here, with
#' \code{\link{message}}. \code{options(livekitr.log = )} sets the most
#' verbose level shown: \code{"none"}, \code{"error"}, \code{"warn"} (the
#' default), \code{"info"}, \code{"debug"} or \code{"trace"}.
#'
#' @param session A session from \code{\link{lk_connect}}.
#' @param timeout Seconds to wait for something to arrive. The default
#'   returns at once.
#' @return A list of events, oldest first; empty if there were none. Each
#'   event is a list with a \code{type}, such as
#'   \code{"participant_connected"}, \code{"participant_disconnected"},
#'   \code{"track_published"}, \code{"track_subscribed"},
#'   \code{"track_unsubscribed"}, \code{"connection_state_changed"},
#'   \code{"e2ee_state_changed"} or \code{"disconnected"}, plus the fields
#'   of that type (for example \code{identity} and \code{track_sid}, or
#'   \code{state} such as \code{"MISSING_KEY"}). Other LiveKit room events
#'   are returned with their \code{type} only.
#' @examples
#' \dontrun{
#' repeat {
#'     for (event in lk_poll(session, timeout = 0.5)) {
#'         cat(event$type, "\n")
#'     }
#' }
#' }
#' @export
lk_poll <- function(session, timeout = 0) {
    session_check(session)
    stopifnot(is.numeric(timeout), length(timeout) == 1L, !is.na(timeout))
    ffi_start()
    pump_until(function() {
        length(session$events) > 0L || length(session$audio) > 0L
    }, timeout)
    audio_deliver(session)
    events <- session$events
    session$events <- list()
    events
}
