## Event routing. livekit-ffi queues events natively; pump() drains the
## queue on the R main thread and files each event with the session or
## pending request it belongs to. User callbacks never run here: lk_poll()
## is the only place they are called.

## FfiEvent members that complete a request, keyed by async id.
async_members <- c("capture_audio_frame", "connect", "disconnect",
                   "publish_track", "unpublish_track", "dispose")

log_levels <- c("error", "warn", "info", "debug", "trace")

## Most verbose LogLevel number to show (LOG_ERROR = 0 to LOG_TRACE = 4),
## from options(livekitr.log = ); -1 for "none". Unknown values mean "warn".
log_threshold <- function() {
    level <- getOption("livekitr.log", "warn")
    threshold <- match(level, c("none", log_levels)) - 2L
    if (length(threshold) != 1L || is.na(threshold)) 1L else threshold
}

## Tell the native callback which log events to queue at all.
log_sync <- function() {
    threshold <- log_threshold()
    if (!identical(threshold, .lk$log_threshold)) {
        .Call(livekitr_log_level, threshold)
        .lk$log_threshold <- threshold
    }
    invisible(NULL)
}

pump <- function() {
    log_sync()
    events <- .Call(livekitr_drain)
    for (bytes in events) {
        route_event(RProtoBuf::read(.lk$event_type, bytes))
    }
    dropped <- .Call(livekitr_dropped)
    if (dropped > (.lk$dropped %||% 0)) {
        warning(dropped - (.lk$dropped %||% 0),
                " LiveKit event(s) were lost: out of memory", call. = FALSE)
        .lk$dropped <- dropped
    }
    length(events)
}

route_event <- function(event) {
    if (event$has("audio_stream_event")) {
        return(route_audio(event$audio_stream_event))
    }
    if (event$has("room_event")) {
        return(route_room(event$room_event))
    }
    if (event$has("logs")) {
        return(route_logs(event$logs))
    }
    if (event$has("panic")) {
        .lk$panic <- event$panic$message
        return(invisible(NULL))
    }
    member <- which_member(event, async_members)
    if (!is.na(member)) {
        route_async(member, event[[member]])
    }
    invisible(NULL)
}

route_async <- function(member, callback) {
    key <- id_key(callback$async_id)
    if (is.null(.lk$ignored[[key]])) {
        .lk$async[[key]] <- callback
        return(invisible(NULL))
    }
    ## Nobody is waiting for this result.
    rm(list = key, envir = .lk$ignored)
    if (member == "connect" && callback$has("result")) {
        ## A connect that finished after lk_connect() gave up: leave the
        ## room. livekit-ffi panics if a joined room is never acknowledged.
        handle <- callback$result$room$handle$id
        ffi_call("ready_for_room_event",
                 pb("ReadyForRoomEventRequest", room_handle = handle))
        response <- ffi_call("disconnect",
                             pb("DisconnectRequest", room_handle = handle))
        ignore_async(response$async_id)
        ffi_drop(handle)
    } else if (callback$has("error")) {
        warning("LiveKit ", gsub("_", " ", member), " failed: ",
                callback$error, call. = FALSE)
    }
    invisible(NULL)
}

route_logs <- function(batch) {
    threshold <- log_threshold()
    for (record in batch$records) {
        if (record$level <= threshold) {
            message("livekit [", log_levels[record$level + 1L], "] ",
                    record$target, ": ", record$message)
        }
    }
    invisible(NULL)
}

route_room <- function(room_event) {
    session <- .lk$rooms[[id_key(room_event$room_handle)]]
    if (is.null(session)) {
        return(invisible(NULL))
    }
    member <- which_member(room_event, .lk$room_members)
    if (is.na(member)) {
        return(invisible(NULL))
    }
    payload <- room_event[[member]]
    event <- switch(member,
                    participant_connected = on_participant_connected(session, payload),
                    participant_disconnected = on_participant_disconnected(session,
            payload),
                    track_published = on_track_published(session, payload),
                    track_subscribed = on_track_subscribed(session, payload),
                    track_unsubscribed = on_track_unsubscribed(session, payload),
                    connection_state_changed = list(
            state = enum_name("ConnectionState", payload$state)),
                    disconnected = on_disconnected(session, payload),
                    e2ee_state_changed = list(
            identity = payload$participant_identity,
            state = enum_name("EncryptionState", payload$state)),
                    participant_encryption_status_changed = list(
            identity = payload$participant_identity,
            encrypted = payload$is_encrypted),
                    list())
    session$events[[length(session$events) + 1L]] <- c(list(type = member),
        event)
    invisible(NULL)
}

on_participant_connected <- function(session, payload) {
    info <- payload$info$info
    session$handles <- c(session$handles, payload$info$handle$id)
    session$participants[[info$identity]] <- list(sid = info$sid,
        name = info$name)
    list(identity = info$identity, name = info$name)
}

on_participant_disconnected <- function(session, payload) {
    session$participants[[payload$participant_identity]] <- NULL
    list(identity = payload$participant_identity,
         reason = enum_name("DisconnectReason", payload$disconnect_reason))
}

on_track_published <- function(session, payload) {
    info <- payload$publication$info
    session$handles <- c(session$handles, payload$publication$handle$id)
    list(identity = payload$participant_identity, track_sid = info$sid,
         kind = enum_name("TrackKind", info$kind))
}

on_track_subscribed <- function(session, payload) {
    info <- payload$track$info
    kind <- enum_name("TrackKind", info$kind)
    session$tracks[[info$sid]] <- list(handle = payload$track$handle$id,
                                       identity = payload$participant_identity,
                                       kind = kind, stream = NULL)
    if (!is.null(session$on_audio)) {
        stream_open(session, info$sid)
    }
    list(identity = payload$participant_identity, track_sid = info$sid,
         kind = kind)
}

on_track_unsubscribed <- function(session, payload) {
    track_close(session, payload$track_sid)
    list(identity = payload$participant_identity, track_sid = payload$track_sid)
}

on_disconnected <- function(session, payload) {
    session$connected <- FALSE
    list(reason = enum_name("DisconnectReason", payload$reason))
}

route_audio <- function(audio_event) {
    key <- id_key(audio_event$stream_handle)
    stream <- .lk$streams[[key]]
    if (audio_event$has("frame_received")) {
        frame <- audio_event$frame_received$frame
        info <- frame$info
        ## Always take the frame: that is what releases it natively.
        pcm <- .Call(livekitr_take_frame, as.numeric(info$data_ptr),
                     as.integer(info$num_channels * info$samples_per_channel),
                     as.numeric(frame$handle$id))
        if (!is.null(stream)) {
            session <- stream$session
            session$audio[[length(session$audio) + 1L]] <- list(
                track_sid = stream$track_sid, identity = stream$identity,
                pcm = pcm)
        }
    } else if (audio_event$has("eos") && !is.null(stream)) {
        stream_close(stream$session, stream$track_sid)
    }
    invisible(NULL)
}

## Pump until `done()` is true or `timeout` seconds pass. Waits in short
## native slices so the R session stays interruptible.
pump_until <- function(done, timeout) {
    deadline <- Sys.time() + timeout
    repeat {
        pump()
        if (!is.null(.lk$panic)) {
            stop("livekit-ffi panicked: ", .lk$panic, call. = FALSE)
        }
        if (done()) {
            return(TRUE)
        }
        left <- as.numeric(difftime(deadline, Sys.time(), units = "secs"))
        if (left <= 0) {
            return(FALSE)
        }
        .Call(livekitr_wait, as.integer(ceiling(min(left, 0.1) * 1000)))
    }
}

## Wait for the callback that completes an asynchronous request.
await <- function(async_id, timeout, what) {
    key <- id_key(async_id)
    if (!pump_until(function() !is.null(.lk$async[[key]]), timeout)) {
        .lk$ignored[[key]] <- TRUE
        stop(what, " timed out after ", timeout, " seconds", call. = FALSE)
    }
    callback <- .lk$async[[key]]
    rm(list = key, envir = .lk$async)
    callback
}

## Let an asynchronous request finish unobserved; route_async() reports
## its error, if any.
ignore_async <- function(async_id) {
    .lk$ignored[[id_key(async_id)]] <- TRUE
    invisible(NULL)
}
