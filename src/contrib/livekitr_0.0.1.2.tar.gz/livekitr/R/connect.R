## Room options livekit-ffi accepts through lk_connect(opts = ).
room_option_names <- c("auto_subscribe", "adaptive_stream", "dynacast",
                       "join_retries", "connect_timeout_ms",
                       "single_peer_connection", "ice_transport")

## IceTransportType numbers by the names lk_connect() accepts.
ice_transports <- c(relay = 0L, nohost = 1L, all = 2L)

room_options <- function(opts, e2ee) {
    if (!is.list(opts) || (length(opts) > 0L && is.null(names(opts)))) {
        stop("`opts` must be a named list", call. = FALSE)
    }
    unknown <- setdiff(names(opts), room_option_names)
    if (length(unknown) > 0L) {
        stop("unknown room option(s): ", paste(unknown, collapse = ", "),
             "; available: ", paste(room_option_names, collapse = ", "),
             call. = FALSE)
    }
    if (is.null(opts$auto_subscribe)) {
        opts$auto_subscribe <- TRUE
    }
    ice_transport <- opts$ice_transport
    opts$ice_transport <- NULL
    options <- do.call(pb, c(list("RoomOptions"), opts))
    if (!is.null(ice_transport)) {
        ice_transport <- match.arg(ice_transport, names(ice_transports))
        options$rtc_config <- pb("RtcConfig",
            ice_transport_type = ice_transports[[ice_transport]])
    }
    if (!is.null(e2ee)) {
        options$encryption <- e2ee_options(e2ee)
    }
    options
}

#' Join a LiveKit room
#'
#' Connects to a LiveKit server and joins the room named in \code{token}.
#' The call returns once the room is joined. Room events and received
#' audio are then queued natively; call \code{\link{lk_poll}} to collect
#' them.
#'
#' @param url WebSocket URL of the LiveKit server, e.g.
#'   \code{"wss://livekit.example.org"}.
#' @param token A signed access token (JWT) granting access to the room;
#'   see \code{\link{lk_mint_token}}.
#' @param e2ee \code{NULL} for no end-to-end encryption, or the shared key
#'   (a string or raw vector) to encrypt media with. A list gives full
#'   control: \code{shared_key}, \code{ratchet_salt},
#'   \code{ratchet_window_size}, \code{failure_tolerance},
#'   \code{key_ring_size} and \code{kdf} (\code{"pbkdf2"} or
#'   \code{"hkdf"}); omit \code{shared_key} to set per-participant keys
#'   later with \code{\link{lk_set_e2ee_key}}.
#' @param opts Named list of room options: \code{auto_subscribe} (default
#'   \code{TRUE}), \code{adaptive_stream}, \code{dynacast},
#'   \code{join_retries}, \code{connect_timeout_ms},
#'   \code{single_peer_connection}, and \code{ice_transport}:
#'   \code{"all"} (the default), \code{"nohost"}, or \code{"relay"} to
#'   send media only through a TURN relay.
#' @param timeout Seconds to wait for the room to be joined.
#' @return An object of class \code{"lk_session"}.
#' @examples
#' \dontrun{
#' token <- lk_mint_token("devkey", "secret", room = "demo", identity = "r")
#' session <- lk_connect("ws://localhost:7880", token)
#' lk_poll(session, timeout = 1)
#' lk_disconnect(session)
#' }
#' @export
lk_connect <- function(url, token, e2ee = NULL, opts = list(), timeout = 30) {
    stopifnot(is.character(url), length(url) == 1L, !is.na(url),
              is.character(token), length(token) == 1L, !is.na(token),
              is.numeric(timeout), length(timeout) == 1L)
    ffi_start()
    response <- ffi_call("connect", pb("ConnectRequest", url = url,
                                       token = token,
                                       options = room_options(opts, e2ee)))
    callback <- await(response$async_id, timeout, paste("connecting to", url))
    if (callback$has("error")) {
        stop("could not join the room at ", url, ": ", callback$error,
             call. = FALSE)
    }
    session <- session_new(url, callback$result)
    session$e2ee <- !is.null(e2ee)
    .lk$rooms[[id_key(session$room_handle)]] <- session
    ## livekit-ffi holds room events back until the client says it is ready.
    ffi_call("ready_for_room_event",
             pb("ReadyForRoomEventRequest", room_handle = session$room_handle))
    session
}

#' Leave a LiveKit room
#'
#' Unpublishes local audio, stops receiving, leaves the room and releases
#' the native resources of the session. Calling it on a session that has
#' already left is harmless.
#'
#' @param session A session from \code{\link{lk_connect}}.
#' @param timeout Seconds to wait for the server to acknowledge.
#' @return \code{NULL}, invisibly.
#' @export
lk_disconnect <- function(session, timeout = 10) {
    stopifnot(inherits(session, "lk_session"))
    if (isTRUE(session$closed)) {
        return(invisible(NULL))
    }
    session$closed <- TRUE
    session$connected <- FALSE
    for (sid in names(session$tracks)) {
        track_close(session, sid)
    }
    response <- ffi_call("disconnect",
                         pb("DisconnectRequest", room_handle = session$room_handle))
    tryCatch(await(response$async_id, timeout, "leaving the room"),
             error = function(e) warning(conditionMessage(e), call. = FALSE))
    for (handle in c(unlist(session$publish[c("publication", "track",
                        "source")]),
                     session$handles, session$room_handle)) {
        ffi_drop(handle)
    }
    rm(list = id_key(session$room_handle), envir = .lk$rooms)
    invisible(NULL)
}
