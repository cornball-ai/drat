#' @useDynLib livekitr, .registration = TRUE
NULL

## Process-wide state: the loaded livekit-ffi library, whether its
## runtime is started, and the tables that route events to sessions.
.lk <- new.env(parent = emptyenv())

## R does not unload package DLLs at exit; stop livekit-ffi then too, so
## open rooms are left cleanly rather than timing out on the server.
.onLoad <- function(libname, pkgname) {
    reg.finalizer(.lk, function(e) {
        if (!is.null(getLoadedDLLs()[["livekitr"]])) {
            ffi_stop()
        }
    }, onexit = TRUE)
}

.onUnload <- function(libpath) {
    ffi_stop()
}
