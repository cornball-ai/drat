# livekitr 0.0.1.2

* The `livekit-ffi` library is no longer bundled. `lk_install_ffi()`
  downloads LiveKit's prebuilt library for the platform on request,
  verifies its sha256 and unpacks it into
  `tools::R_user_dir("livekitr", "data")`, where the package finds it.
  `LIVEKIT_FFI_LIB` and the system library directories are also searched.
* `inst/COPYRIGHTS` records LiveKit, Inc. as the copyright holder of the
  protobuf schemas.

# livekitr 0.0.1.1

* `lk_set_e2ee_key()` also switches the sender to the key index it was
  given; before, livekit-ffi kept encrypting with index 0 and every
  rotation went silent.
* `lk_connect()` takes `opts = list(ice_transport = "relay")` to force
  media through a TURN relay.
* `lk_poll()` reports `e2ee_state_changed` and
  `participant_encryption_status_changed` events with their fields.

# livekitr 0.0.1

* First working version: join a LiveKit room, publish 16-bit PCM as a
  microphone track, and receive each remote participant's audio.
* Drives the prebuilt `livekit-ffi` library (v0.12.81), loaded at runtime.
  Requests and events are protobuf messages handled with RProtoBuf.
* `lk_connect()`, `lk_disconnect()`, `lk_publish_pcm()`, `lk_on_audio()`,
  `lk_poll()`, `lk_set_e2ee_key()`, `lk_mint_token()` and
  `livekit_available()`.
