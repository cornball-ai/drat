# livekitr

A [LiveKit](https://livekit.io/) client for R: join a room, publish audio,
and receive each participant's audio as 16-bit PCM.

livekitr does not reimplement WebRTC. It drives LiveKit's prebuilt
[`livekit-ffi`](https://github.com/livekit/rust-sdks) library, the same
one the Python and Node SDKs use. Requests and events cross the native
boundary as protobuf messages, which
[RProtoBuf](https://cran.r-project.org/package=RProtoBuf) encodes and
decodes from the schemas in `inst/proto`.

## Example

```r
library(livekitr)

token <- lk_mint_token("devkey", "secret", room = "demo", identity = "r-agent")
session <- lk_connect("ws://localhost:7880", token)

# One call per speaker: LiveKit delivers a separate track per participant.
lk_on_audio(session, function(pcm, info) {
    cat(info$identity, "sent", length(pcm), "samples\n")
})

# One second of a 440 Hz tone, as this participant's microphone.
tone <- as.integer(8000 * sin(2 * pi * 440 * seq_len(48000) / 48000))
lk_publish_pcm(session, tone)

# Events and audio are delivered only when polled.
for (event in lk_poll(session, timeout = 1)) {
    cat(event$type, "\n")
}

lk_disconnect(session)
```

## How it runs

- `livekit-ffi` owns the network, the codecs and its own threads. Those
  threads never call the R API. Events are copied into a native queue,
  and `lk_poll()` drains it on the R main thread. Callbacks registered
  with `lk_on_audio()` run only inside `lk_poll()`.
- Audio is 16-bit PCM. `lk_publish_pcm()` takes any sample rate and
  channel count (fixed by the first call); `lk_on_audio()` asks the
  library to resample to the rate you want.
- End-to-end encryption uses a key supplied from R: pass `e2ee =` to
  `lk_connect()`, rotate with `lk_set_e2ee_key()`.
- `options(livekitr.log = "debug")` shows the native library's log.

## The native library

The package needs `liblivekit_ffi` (v0.12.81). It is not part of the
package, which keeps the package free of binaries; it is loaded at
runtime rather than linked. Once, per machine:

```r
livekitr::lk_install_ffi()
```

That downloads LiveKit's prebuilt library for your platform (about
10 MB, Linux, macOS and Windows) from the
[`livekit-ffi/v0.12.81` release](https://github.com/livekit/rust-sdks/releases/tag/livekit-ffi%2Fv0.12.81),
checks it against the sha256 recorded in the package, and unpacks it
with LiveKit's third-party notices into `tools::R_user_dir("livekitr",
"data")`. The library is looked up, in order, at the path in
`LIVEKIT_FFI_LIB`, in that directory, then in the usual system library
directories. Without it the package still installs: `livekit_available()`
returns `FALSE`, and `lk_mint_token()` keeps working.

## Tests

`inst/tinytest/test_room.R` exercises a real server and is skipped unless
`LIVEKITR_TEST_URL` is set:

```sh
docker run --rm --network host livekit/livekit-server --dev \
    --bind 127.0.0.1 --node-ip 127.0.0.1
LIVEKITR_TEST_URL=ws://127.0.0.1:7880 \
    Rscript --vanilla -e 'tinytest::run_test_dir("inst/tinytest")'
```

## License

Apache License 2.0. The schemas in `inst/proto`, and the `livekit-ffi`
library that `lk_install_ffi()` downloads, are Copyright LiveKit, Inc.,
also under Apache 2.0; see `inst/COPYRIGHTS`.
