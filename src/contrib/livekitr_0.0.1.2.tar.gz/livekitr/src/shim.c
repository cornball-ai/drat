// Bridge to the livekit-ffi C ABI.
//
// livekit-ffi takes protobuf request bytes and returns protobuf response
// bytes; asynchronous results and room events arrive on a callback that
// livekit-ffi invokes from its own threads. The callback here never
// calls the R API: it copies the event bytes into a native queue, and
// the R main thread drains that queue when it polls.
//
// The library is not linked. R loads it with dyn.load() and hands the
// four entry points to livekitr_start(), so the package builds and
// installs on platforms that have no livekit-ffi library.

#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>

#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef void (*lk_callback_fn)(const uint8_t *, size_t);
typedef void (*lk_initialize_fn)(lk_callback_fn, bool, const char *,
                                 const char *);
typedef uint64_t (*lk_request_fn)(const uint8_t *, size_t, const uint8_t **,
                                  size_t *);
typedef bool (*lk_drop_handle_fn)(uint64_t);
typedef void (*lk_dispose_fn)(void);

typedef struct lk_event {
    struct lk_event *next;
    size_t len;
    uint8_t data[];
} lk_event;

static pthread_mutex_t lk_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t lk_ready = PTHREAD_COND_INITIALIZER;
static lk_event *lk_head = NULL;
static lk_event *lk_tail = NULL;
static size_t lk_queued = 0;
static double lk_dropped = 0;

static lk_request_fn ffi_request = NULL;
static lk_drop_handle_fn ffi_drop_handle = NULL;
static lk_dispose_fn ffi_dispose = NULL;
static int lk_started = 0;

// Most verbose log level to queue: LOG_ERROR = 0 up to LOG_TRACE = 4, or
// -1 to discard every log event.
static atomic_int lk_log_level = 1;

static bool lk_varint(const uint8_t **p, const uint8_t *end, uint64_t *out) {
    uint64_t value = 0;
    for (int shift = 0; shift < 64 && *p < end; shift += 7) {
        uint8_t byte = *(*p)++;
        value |= (uint64_t) (byte & 0x7f) << shift;
        if ((byte & 0x80) == 0) {
            *out = value;
            return true;
        }
    }
    return false;
}

// Most severe level among the records of a log event, or -1 when the
// event is not a log batch or does not parse as one. livekit-ffi forwards
// every log record of libwebrtc as an event, tens of thousands during
// connection setup, so the unwanted ones are discarded here and never
// reach R. An event is FfiEvent{logs = 18: LogBatch{records = 1:
// LogRecord{level = 1, ...}}}.
static int lk_log_severity(const uint8_t *data, size_t len) {
    const uint8_t *p = data;
    const uint8_t *end = data + len;
    uint64_t size;
    if (len < 2 || p[0] != 0x92 || p[1] != 0x01) {
        return -1;
    }
    p += 2;
    if (!lk_varint(&p, end, &size) || size != (uint64_t) (end - p)) {
        return -1;
    }
    int severity = -1;
    while (p < end) {
        if (*p++ != 0x0a || !lk_varint(&p, end, &size) ||
            size > (uint64_t) (end - p)) {
            return -1;
        }
        const uint8_t *record = p;
        const uint8_t *record_end = p + size;
        uint64_t level;
        if (size < 2 || *record++ != 0x08 ||
            !lk_varint(&record, record_end, &level) || level > 4) {
            return -1;
        }
        if (severity < 0 || (int) level < severity) {
            severity = (int) level;
        }
        p = record_end;
    }
    return severity;
}

// Runs on livekit-ffi's threads. `data` is only valid during the call.
static void lk_on_event(const uint8_t *data, size_t len) {
    if (lk_log_severity(data, len) > atomic_load(&lk_log_level)) {
        return;
    }
    lk_event *ev = malloc(sizeof(lk_event) + len);
    if (ev != NULL) {
        ev->next = NULL;
        ev->len = len;
        memcpy(ev->data, data, len);
    }
    pthread_mutex_lock(&lk_lock);
    if (ev == NULL) {
        lk_dropped += 1;
    } else {
        if (lk_tail == NULL) {
            lk_head = ev;
        } else {
            lk_tail->next = ev;
        }
        lk_tail = ev;
        lk_queued += 1;
        pthread_cond_signal(&lk_ready);
    }
    pthread_mutex_unlock(&lk_lock);
}

static void lk_require_started(void) {
    if (!lk_started) {
        Rf_error("livekit-ffi is not started");
    }
}

// Handles, async ids and addresses cross into R as doubles, which hold
// integers exactly up to 2^53.
static uint64_t lk_u64(SEXP x, const char *what) {
    if (TYPEOF(x) != REALSXP || XLENGTH(x) != 1) {
        Rf_error("%s must be a single number", what);
    }
    double v = REAL(x)[0];
    if (!R_FINITE(v) || v < 0 || v > 9007199254740992.0 || v != floor(v)) {
        Rf_error("%s is not a valid unsigned integer", what);
    }
    return (uint64_t) v;
}

static void *lk_symbol(SEXP sym, const char *name) {
    if (TYPEOF(sym) != EXTPTRSXP) {
        Rf_error("%s is not a native symbol", name);
    }
    DL_FUNC fn = R_ExternalPtrAddrFn(sym);
    if (fn == NULL) {
        Rf_error("%s has a null address", name);
    }
    return (void *) fn;
}

SEXP livekitr_start(SEXP initialize, SEXP request, SEXP drop_handle,
                    SEXP dispose, SEXP sdk_version) {
    if (lk_started) {
        return R_NilValue;
    }
    if (TYPEOF(sdk_version) != STRSXP || XLENGTH(sdk_version) != 1) {
        Rf_error("sdk_version must be a single string");
    }
    lk_initialize_fn ffi_initialize =
        (lk_initialize_fn) lk_symbol(initialize, "livekit_ffi_initialize");
    ffi_request = (lk_request_fn) lk_symbol(request, "livekit_ffi_request");
    ffi_drop_handle =
        (lk_drop_handle_fn) lk_symbol(drop_handle, "livekit_ffi_drop_handle");
    ffi_dispose = (lk_dispose_fn) lk_symbol(dispose, "livekit_ffi_dispose");
    // LiveKit's signaling protocol has a fixed list of SDK names and R is
    // not on it; "rust" names the client that actually runs.
    ffi_initialize(lk_on_event, true, "rust",
                   CHAR(STRING_ELT(sdk_version, 0)));
    lk_started = 1;
    return R_NilValue;
}

SEXP livekitr_request(SEXP bytes) {
    lk_require_started();
    if (TYPEOF(bytes) != RAWSXP) {
        Rf_error("request must be a raw vector");
    }
    const uint8_t *res = NULL;
    size_t res_len = 0;
    uint64_t handle = ffi_request(RAW(bytes), (size_t) XLENGTH(bytes), &res,
                                  &res_len);
    if (handle == 0) {
        Rf_error("livekit-ffi rejected the request");
    }
    // The response bytes belong to `handle`; copy them, then release it.
    SEXP out = PROTECT(Rf_allocVector(RAWSXP, (R_xlen_t) res_len));
    if (res_len > 0) {
        memcpy(RAW(out), res, res_len);
    }
    ffi_drop_handle(handle);
    UNPROTECT(1);
    return out;
}

// Wait up to timeout_ms for an event to be queued. The R side calls this
// in short slices so the wait stays interruptible.
SEXP livekitr_wait(SEXP timeout_ms) {
    int ms = Rf_asInteger(timeout_ms);
    if (ms == NA_INTEGER || ms < 0) {
        Rf_error("timeout_ms must be a non-negative integer");
    }
    struct timespec until;
    clock_gettime(CLOCK_REALTIME, &until);
    until.tv_sec += ms / 1000;
    until.tv_nsec += (long) (ms % 1000) * 1000000L;
    if (until.tv_nsec >= 1000000000L) {
        until.tv_sec += 1;
        until.tv_nsec -= 1000000000L;
    }
    pthread_mutex_lock(&lk_lock);
    while (lk_queued == 0) {
        if (pthread_cond_timedwait(&lk_ready, &lk_lock, &until) == ETIMEDOUT) {
            break;
        }
    }
    int ready = lk_queued > 0;
    pthread_mutex_unlock(&lk_lock);
    return Rf_ScalarLogical(ready);
}

// Take every queued event as a list of raw vectors, oldest first.
SEXP livekitr_drain(void) {
    pthread_mutex_lock(&lk_lock);
    lk_event *ev = lk_head;
    size_t n = lk_queued;
    lk_head = NULL;
    lk_tail = NULL;
    lk_queued = 0;
    pthread_mutex_unlock(&lk_lock);

    SEXP out = PROTECT(Rf_allocVector(VECSXP, (R_xlen_t) n));
    for (R_xlen_t i = 0; ev != NULL; i++) {
        SEXP bytes = Rf_allocVector(RAWSXP, (R_xlen_t) ev->len);
        SET_VECTOR_ELT(out, i, bytes);
        if (ev->len > 0) {
            memcpy(RAW(bytes), ev->data, ev->len);
        }
        lk_event *next = ev->next;
        free(ev);
        ev = next;
    }
    UNPROTECT(1);
    return out;
}

SEXP livekitr_log_level(SEXP level) {
    int value = Rf_asInteger(level);
    if (value == NA_INTEGER || value < -1 || value > 4) {
        Rf_error("level must be between -1 and 4");
    }
    atomic_store(&lk_log_level, value);
    return R_NilValue;
}

// The severity lk_on_event() sees for an event; exposed for testing.
SEXP livekitr_log_severity(SEXP bytes) {
    if (TYPEOF(bytes) != RAWSXP) {
        Rf_error("bytes must be a raw vector");
    }
    return Rf_ScalarInteger(lk_log_severity(RAW(bytes),
                                            (size_t) XLENGTH(bytes)));
}

// Events lost because the callback could not allocate.
SEXP livekitr_dropped(void) {
    pthread_mutex_lock(&lk_lock);
    double n = lk_dropped;
    pthread_mutex_unlock(&lk_lock);
    return Rf_ScalarReal(n);
}

SEXP livekitr_drop_handle(SEXP handle) {
    lk_require_started();
    return Rf_ScalarLogical(ffi_drop_handle(lk_u64(handle, "handle")));
}

// Address of a raw vector's bytes, for the data_ptr field of a capture
// request. livekit-ffi copies the samples during the request call, so
// the vector only has to stay alive for that call.
SEXP livekitr_address(SEXP x) {
    if (TYPEOF(x) != RAWSXP) {
        Rf_error("x must be a raw vector");
    }
    return Rf_ScalarReal((double) (uintptr_t) RAW(x));
}

// Copy a received audio frame (int16 samples at `address`, owned by
// `handle`) into an integer vector, then release the frame.
SEXP livekitr_take_frame(SEXP address, SEXP n_samples, SEXP handle) {
    lk_require_started();
    uint64_t addr = lk_u64(address, "address");
    uint64_t id = lk_u64(handle, "handle");
    int n = Rf_asInteger(n_samples);
    if (addr == 0 || n == NA_INTEGER || n < 0) {
        Rf_error("invalid audio frame");
    }
    SEXP out = PROTECT(Rf_allocVector(INTSXP, n));
    const int16_t *src = (const int16_t *) (uintptr_t) addr;
    int *dst = INTEGER(out);
    for (int i = 0; i < n; i++) {
        dst[i] = src[i];
    }
    ffi_drop_handle(id);
    UNPROTECT(1);
    return out;
}

static void lk_free_queue(void) {
    pthread_mutex_lock(&lk_lock);
    lk_event *ev = lk_head;
    lk_head = NULL;
    lk_tail = NULL;
    lk_queued = 0;
    pthread_mutex_unlock(&lk_lock);
    while (ev != NULL) {
        lk_event *next = ev->next;
        free(ev);
        ev = next;
    }
}

// Close every room and stop livekit-ffi's runtime. Idempotent.
SEXP livekitr_dispose(void) {
    if (lk_started) {
        lk_started = 0;
        ffi_dispose();
        lk_free_queue();
    }
    return R_NilValue;
}
