// Routine registration.

#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

extern SEXP livekitr_start(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP livekitr_request(SEXP);
extern SEXP livekitr_wait(SEXP);
extern SEXP livekitr_drain(void);
extern SEXP livekitr_log_level(SEXP);
extern SEXP livekitr_log_severity(SEXP);
extern SEXP livekitr_dropped(void);
extern SEXP livekitr_drop_handle(SEXP);
extern SEXP livekitr_address(SEXP);
extern SEXP livekitr_take_frame(SEXP, SEXP, SEXP);
extern SEXP livekitr_dispose(void);

static const R_CallMethodDef call_methods[] = {
    {"livekitr_start", (DL_FUNC) &livekitr_start, 5},
    {"livekitr_request", (DL_FUNC) &livekitr_request, 1},
    {"livekitr_wait", (DL_FUNC) &livekitr_wait, 1},
    {"livekitr_drain", (DL_FUNC) &livekitr_drain, 0},
    {"livekitr_log_level", (DL_FUNC) &livekitr_log_level, 1},
    {"livekitr_log_severity", (DL_FUNC) &livekitr_log_severity, 1},
    {"livekitr_dropped", (DL_FUNC) &livekitr_dropped, 0},
    {"livekitr_drop_handle", (DL_FUNC) &livekitr_drop_handle, 1},
    {"livekitr_address", (DL_FUNC) &livekitr_address, 1},
    {"livekitr_take_frame", (DL_FUNC) &livekitr_take_frame, 3},
    {"livekitr_dispose", (DL_FUNC) &livekitr_dispose, 0},
    {NULL, NULL, 0}
};

void R_init_livekitr(DllInfo *dll) {
    R_registerRoutines(dll, NULL, call_methods, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
