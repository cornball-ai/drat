#' tree-sitter language for Python
#'
#' `language()` returns a `tree_sitter_language` object for Python, for use with
#' a tree-sitter runtime such as the treesitter or bonsaisitter package.
#'
#' @returns A `tree_sitter_language` object.
#'
#' @export
#' @examples
#' language()
language <- function() {
  pointer <- .Call(ffi_language)

  new_language(
    pointer = pointer,
    abi = abi(),
    name = "python"
  )
}
