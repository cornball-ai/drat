#' @keywords internal
#' @useDynLib treesitter.python, .registration = TRUE
"_PACKAGE"
