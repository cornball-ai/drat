# Stateful E2EE integration: session management on top of the crypto.R
# primitives. These functions turn "send this to an encrypted room" and
# "decrypt this sync" into concrete payloads and plaintext, holding the
# Olm and Megolm sessions in between. Transport (claiming one-time keys,
# sending to-device, sending the event) stays with the caller / mx.api;
# this layer is pure crypto state, so it is testable without a server.
#
# A session set is a list with five named maps:
#   olm        peer Curve25519 -> outbound Olm session (we encrypt to them)
#   olm_in     peer Curve25519 -> inbound Olm session  (they encrypt to us)
#   megolm_out room id          -> list(session, shared = peer curves)
#   megolm_in  "room|session_id" -> list(session, sender, sender_ed25519,
#                                        sender_bound)
#   key_requests "room|session_id" -> outstanding m.room_key_request metadata,
#                                        including whether transport succeeded
#
# megolm_in carries the sender identity the Olm payload claimed when the
# key was shared, plus whether that claim was tied to a device whose
# device_keys verified. The claim alone is not evidence -- anyone can open
# an Olm session to us -- so only sender_bound justifies reporting a
# decrypted event as sender-verified. Stores written before this existed
# hold a bare pickle string there and are migrated on load.

#' Create an empty E2EE session set
#'
#' @return A session set: named lists \code{olm}, \code{olm_in},
#'   \code{megolm_out}, \code{megolm_in}, and \code{key_requests}.
#' @examples
#' s <- mx_crypto_sessions_new()
#' names(s)
#' @export
mx_crypto_sessions_new <- function() {
    list(olm = list(), olm_in = list(), megolm_out = list(),
         megolm_in = list(), key_requests = list())
}

#' Persist a session set to the crypto store
#'
#' Pickles every live session (encrypted at rest with the store key) into
#' \code{sessions.json}. Reload with \code{mx_crypto_sessions_load()}.
#' New files declare schema version 1; unversioned legacy files remain readable.
#'
#' @param sessions A session set.
#' @param store_dir Character. Crypto store directory.
#' @return The path written, invisibly.
#' @examples
#' \donttest{
#' if (requireNamespace("mx.crypto", quietly = TRUE)) {
#'   dir <- file.path(tempfile(), "crypto")
#'   mx_crypto_sessions_save(mx_crypto_sessions_new(), dir)
#' }
#' }
#' @export
mx_crypto_sessions_save <- function(sessions, store_dir) {
    mx_require_crypto()
    dir.create(store_dir, showWarnings = FALSE, recursive = TRUE)
    key <- mx_crypto_key(store_dir)
    blob <- list(
                 version = 1L,
                 olm = lapply(sessions$olm, function(s) {
        mx.crypto::mxc_olm_session_pickle(s, key)
    }),
                 olm_in = lapply(sessions$olm_in, function(s) {
        mx.crypto::mxc_olm_session_pickle(s, key)
    }),
                 megolm_out = lapply(sessions$megolm_out, function(m) {
        list(session = mx.crypto::mxc_megolm_outbound_pickle(m$session, key),
             shared = as.list(m$shared))
    }),
        megolm_in = lapply(sessions$megolm_in, function(e) {
        list(session = mx.crypto::mxc_megolm_inbound_pickle(e$session, key),
             sender = e$sender %||% NA_character_,
             sender_ed25519 = e$sender_ed25519 %||% NA_character_,
             sender_bound = isTRUE(e$sender_bound))
    }),
        key_requests = sessions$key_requests %||% list()
    )
    path <- file.path(store_dir, "sessions.json")
    writeLines(jsonlite::toJSON(blob, auto_unbox = TRUE), path)
    Sys.chmod(path, mode = "0600")
    invisible(path)
}

#' Load a session set from the crypto store
#'
#' Accepts version 1 and unversioned legacy stores. Unknown or malformed
#' schema versions are rejected before unpickling, without rewriting the file.
#'
#' @param store_dir Character. Crypto store directory.
#' @return A session set (empty if nothing is stored yet).
#' @examples
#' \donttest{
#' if (requireNamespace("mx.crypto", quietly = TRUE)) {
#'   s <- mx_crypto_sessions_load(file.path(tempfile(), "crypto"))
#' }
#' }
#' @export
mx_crypto_sessions_load <- function(store_dir) {
    mx_require_crypto()
    path <- file.path(store_dir, "sessions.json")
    if (!file.exists(path)) {
        return(mx_crypto_sessions_new())
    }
    blob <- jsonlite::fromJSON(paste(readLines(path, warn = FALSE),
                                     collapse = "\n"),
                               simplifyVector = FALSE)
    crypto_store_version(blob, path, legacy = TRUE)
    key <- mx_crypto_key(store_dir)
    out <- mx_crypto_sessions_new()
    for (nm in names(blob$olm %||% list())) {
        out$olm[[nm]] <- mx.crypto::mxc_olm_session_unpickle(blob$olm[[nm]], key)
    }
    for (nm in names(blob$olm_in %||% list())) {
        out$olm_in[[nm]] <- mx.crypto::mxc_olm_session_unpickle(
            blob$olm_in[[nm]], key)
    }
    for (nm in names(blob$megolm_out %||% list())) {
        m <- blob$megolm_out[[nm]]
        out$megolm_out[[nm]] <- list(
                                     session = mx.crypto::mxc_megolm_outbound_unpickle(m$session, key),
                                     shared = unlist(m$shared, use.names = FALSE) %||% character())
    }
    for (nm in names(blob$megolm_in %||% list())) {
        e <- blob$megolm_in[[nm]]
        # Stores written before sender attestation held a bare pickle
        # string here. Read them rather than discarding them: dropping the
        # entry would cost a running client its ability to decrypt every
        # message in that session's history. Such sessions carry no
        # attested sender, so events they decrypt report
        # sender_verified = FALSE.
        if (is.character(e) || !is.list(e)) {
            out$megolm_in[[nm]] <- list(
                                        session = mx.crypto::mxc_megolm_inbound_unpickle(e, key),
                                        sender = NA_character_,
                                        sender_ed25519 = NA_character_,
                                        sender_bound = FALSE)
            next
        }
        out$megolm_in[[nm]] <- list(
                                    session = mx.crypto::mxc_megolm_inbound_unpickle(e$session, key),
                                    sender = e$sender %||% NA_character_,
                                    sender_ed25519 = e$sender_ed25519 %||% NA_character_,
                                    sender_bound = isTRUE(e$sender_bound))
    }
    out$key_requests <- blob$key_requests %||% list()
    out
}

#' Encrypt an event for an encrypted room's devices
#'
#' Ensures an outbound Megolm session for the room, shares its key with
#' any recipient device that has not received it yet (establishing an Olm
#' session, claiming a one-time key when needed), and encrypts the event.
#' Returns the to-device payloads and the \code{m.room.encrypted} event;
#' the caller sends them with \code{mx.api::mx_send_to_device()} and
#' \code{mx.api::mx_send()}.
#'
#' @param account An mx.crypto account handle.
#' @param sessions A session set.
#' @param room_id Character room id.
#' @param content Named list. Plaintext event content.
#' @param sender_curve25519 Character. This device's Curve25519 key.
#' @param device_id Character. This device's id.
#' @param recipients List of recipient devices, each a list with
#'   \code{user_id}, \code{device_id}, \code{curve25519}, \code{ed25519},
#'   and (only needed to open a new Olm session) \code{otk}, a claimed
#'   one-time key. Use \code{mx_crypto_known_devices()}, which returns
#'   exactly this shape for devices whose keys verified.
#' @param sender_user_id Character. This user's Matrix id. Required to
#'   build a spec-conformant Olm payload that the recipient can attribute.
#' @param event_type Inner Matrix event type, defaulting to m.room.message.
#' @return List with \code{to_device} (per-device payloads), \code{event}
#'   (the \code{m.room.encrypted} content), and the updated \code{sessions}.
#' @examples
#' \donttest{
#' if (requireNamespace("mx.crypto", quietly = TRUE)) {
#'   acct <- mx.crypto::mxc_account_new()
#'   out <- mx_crypto_encrypt_for_devices(
#'     acct, mx_crypto_sessions_new(), "!r:ex",
#'     list(msgtype = "m.text", body = "hi"),
#'     mx.crypto::mxc_account_identity_keys(acct)$curve25519, "DEV",
#'     recipients = list(), sender_user_id = "@me:ex")
#'   names(out)
#' }
#' }
#' @export
mx_crypto_encrypt_for_devices <- function(account, sessions, room_id,
    content, sender_curve25519,
    device_id, recipients = list(),
    sender_user_id = NULL, event_type = "m.room.message") {
    mx_require_crypto()
    if (length(recipients) && is.null(sender_user_id)) {
        stop("sender_user_id is required to share room keys; without it the ",
             "Olm payload cannot name its sender and recipients will ",
             "reject it", call. = FALSE)
    }
    sender_ed25519 <- mx.crypto::mxc_account_identity_keys(account)$ed25519
    mo <- sessions$megolm_out[[room_id]]
    if (is.null(mo)) {
        mo <- list(session = mx.crypto::mxc_megolm_outbound_new(),
                   shared = character())
    }
    # Keep an inbound copy of our outbound session. Homeservers echo our room
    # events through /sync; without this, own echoes generate key requests to
    # this same device. This also repairs older stores on their next send.
    outbound_info <- mx.crypto::mxc_megolm_outbound_info(mo$session)
    own_key <- paste(room_id, outbound_info$session_id, sep = "|")
    if (is.null(sessions$megolm_in[[own_key]])) {
        bound <- is.character(sender_user_id) &&
            length(sender_user_id) == 1L &&
            !is.na(sender_user_id) && nzchar(sender_user_id)
        sessions$megolm_in[[own_key]] <- list(
            session = mx.crypto::mxc_megolm_inbound_new(
                outbound_info$session_key),
            sender = sender_user_id %||% NA_character_,
            sender_ed25519 = sender_ed25519,
            sender_bound = bound)
    }


    to_device <- list()
    for (r in recipients) {
        peer <- r$curve25519
        if (peer %in% mo$shared) {
            next
        }
        if (is.null(r$ed25519) || !nzchar(r$ed25519)) {
            stop("recipient ", r$user_id %||% "<unknown>", "/",
                 r$device_id %||% "<unknown>", " has no ed25519 key; it must ",
                 "come from a verified device (mx_crypto_known_devices())",
                 call. = FALSE)
        }
        olm <- sessions$olm[[peer]]
        if (is.null(olm)) {
            if (is.null(r$otk)) {
                stop("no Olm session for ", peer,
                     " and no one-time key supplied to open one",
                     call. = FALSE)
            }
            olm <- mx.crypto::mxc_olm_create_outbound(
                account, peer_curve25519 = peer, peer_otk = r$otk)
            sessions$olm[[peer]] <- olm
        }
        td <- mx_crypto_room_key_payload(olm, sender_curve25519, peer,
            room_id, mo$session, sender_user_id, sender_ed25519,
            r$user_id, r$ed25519)
        to_device[[length(to_device) + 1L]] <- list(
            user_id = r$user_id, device_id = r$device_id, content = td)
        mo$shared <- c(mo$shared, peer)
    }

    event <- mx_crypto_encrypt_event(mo$session, content, room_id,
                                     sender_curve25519, device_id, event_type)
    sessions$megolm_out[[room_id]] <- mo
    list(to_device = to_device, event = event, sessions = sessions)
}

#' Process a sync response: store room keys, decrypt room events
#'
#' Handles inbound to-device \code{m.room.encrypted} (Olm) messages,
#' storing direct \code{m.room_key} events and requested
#' \code{m.forwarded_room_key} events as inbound Megolm sessions. It then
#' decrypts timeline events whose session is known and queues stable,
#' retryable \code{m.room_key_request} messages for missing sessions. The
#' caller sends those requests to this user's other devices.
#'
#' @param account An mx.crypto account handle.
#' @param sessions A session set.
#' @param sync_resp Parsed \code{/sync} response.
#' @param self_curve25519 Character. This device's Curve25519 key.
#' @param devices List of verified devices from
#'   \code{mx_crypto_known_devices()}, or NULL. Room keys arrive over Olm
#'   carrying a claimed sender, and anyone who can reach this device can
#'   send one, so the claim is only worth something once it is matched
#'   against a device whose \code{device_keys} verified. Without this
#'   list peers' decrypted events report \code{sender_verified = FALSE}:
#'   they still decrypt, but nothing attests to who sent them. Own echoes
#'   can be verified against the locally retained outbound session. Forwarded
#'   keys require this user's cross-signed devices, queried with a trusted
#'   local \code{self_master_key}; they never verify the original sender.
#' @param self_id Character or NULL. This user's Matrix id, for
#'   \code{is_self} tagging and as the recipient of key requests.
#' @param self_device_id Character or NULL. This device id. Both this and
#'   \code{self_id} are required to create room-key requests.
#' @return List with \code{events} (decrypted, normalized), updated
#'   \code{verification_events} (original verification envelopes, separated
#'   from chat messages; no handshake or network side effect is performed),
#'   \code{sessions}, unsent \code{key_requests}, matching
#'   \code{key_request_cancellations}, and \code{incoming_key_requests}
#'   for a policy-aware sharing layer to inspect.
#' @examples
#' \donttest{
#' if (requireNamespace("mx.crypto", quietly = TRUE)) {
#'   acct <- mx.crypto::mxc_account_new()
#'   res <- mx_crypto_process_sync(acct, mx_crypto_sessions_new(),
#'     list(to_device = list(events = list()), rooms = list(join = list())),
#'     mx.crypto::mxc_account_identity_keys(acct)$curve25519)
#'   length(res$events)
#' }
#' }
#' @export
mx_crypto_process_sync <- function(account, sessions, sync_resp,
                                   self_curve25519, self_id = NULL,
                                   devices = NULL, self_device_id = NULL) {
    mx_require_crypto()
    self_ed25519 <- mx.crypto::mxc_account_identity_keys(account)$ed25519
    sessions$key_requests <- sessions$key_requests %||% list()
    cancellations <- list()
    incoming_requests <- list()
    verification_events <- list()

    # 1. To-device: recover shared room keys.
    for (ev in sync_resp$to_device$events %||% list()) {
        if (sas_is_event(ev)) {
            verification_events[[length(verification_events) + 1L]] <- ev
            next
        }
        if (isTRUE(ev$type == "m.room_key_request")) {
            c <- ev$content
            # Wildcard delivery includes this device; do not surface our own
            # request to a future key-sharing layer.
            if (!is.null(self_device_id) &&
                identical(c$requesting_device_id, self_device_id)) next
            if (isTRUE(c$action %in% c("request", "request_cancellation")) &&
                is.character(c$request_id) && nzchar(c$request_id) &&
                is.character(c$requesting_device_id) &&
                nzchar(c$requesting_device_id)) {
                incoming_requests[[length(incoming_requests) + 1L]] <- list(
                    user_id = ev$sender, content = c)
            }
            next
        }
        if (!isTRUE(ev$type == "m.room.encrypted") ||
            !isTRUE(ev$content$algorithm == MX_OLM)) {
            next
        }
        msg <- ev$content$ciphertext[[self_curve25519]]
        if (is.null(msg)) {
            next
        }
        sender <- ev$content$sender_key
        res <- olm_receive(account, sender, msg,
            list(sessions$olm_in[[sender]], sessions$olm[[sender]]))
        if (is.null(res)) next
        if (res$new) {
            sessions$olm_in[[sender]] <- res$session
        }
        decoded <- olm_decode(res$plaintext)
        if (is.null(decoded)) next
        chk <- mx_crypto_check_olm_payload(decoded, self_id, self_ed25519,
            sender, devices)
        if (!chk$ok) {
            next
        }
        if (sas_is_event(decoded)) {
            if (!identical(decoded$sender, ev$sender)) next
            verification_events[[length(verification_events) + 1L]] <- list(
                type = decoded$type, content = decoded$content,
                sender = decoded$sender)
        } else if (identical(decoded$type, "m.room_key")) {
            c <- decoded$content
            if (!identical(c$algorithm, MX_MEGOLM)) {
                next
            }
            key <- paste(c$room_id, c$session_id, sep = "|")
            # Record who the payload claimed to be from, and separately
            # whether that claim was tied to a verified device. Keeping the
            # unbound claim is still useful -- it catches an ordinary user
            # forging a sender, since the server stamps the real one on the
            # envelope -- but only sender_bound justifies calling a
            # decrypted event's sender verified.
            sessions$megolm_in[[key]] <- list(
                session = mx.crypto::mxc_megolm_inbound_new(c$session_key),
                sender = decoded$sender,
                sender_ed25519 = decoded$keys$ed25519,
                sender_bound = chk$bound)
            pending <- sessions$key_requests[[key]]
            if (!is.null(pending)) {
                cancellations[[length(cancellations) + 1L]] <-
                    mx_crypto_key_request_cancellation(pending)
                sessions$key_requests[[key]] <- NULL
            }
        } else if (identical(decoded$type, "m.forwarded_room_key")) {
            c <- decoded$content
            key <- paste(c$room_id, c$session_id, sep = "|")
            pending <- sessions$key_requests[[key]]
            # Forwarded room keys are deliberately much stricter than an
            # ordinary m.room_key. The Matrix spec limits this mechanism to
            # verified devices owned by the requesting user. An unsolicited
            # key, a key from another user, or one from a merely self-signed
            # (not cross-signed) device is ignored.
            forwarder <- mx_crypto_matching_device(decoded, sender, devices)
            trusted_forwarder <- isTRUE(chk$bound) &&
                identical(decoded$sender, self_id) &&
                isTRUE(forwarder$cross_signed)
            valid <- !is.null(pending) && trusted_forwarder &&
                identical(c$algorithm, MX_MEGOLM) &&
                identical(c$room_id, pending$room_id) &&
                identical(c$session_id, pending$session_id) &&
                is.character(c$session_key) && nzchar(c$session_key)
            if (!valid) {
                warning("mx.client: ignoring unsolicited or untrusted ",
                        "m.forwarded_room_key", call. = FALSE)
                next
            }
            inbound <- tryCatch(
                mx.crypto::mxc_megolm_inbound_import(c$session_key),
                error = function(e) NULL)
            if (is.null(inbound) || !identical(
                    mx.crypto::mxc_megolm_inbound_info(inbound)$session_id,
                    pending$session_id)) {
                warning("mx.client: ignoring forwarded room key whose ",
                        "exported session does not match its session_id",
                        call. = FALSE)
                next
            }
            # Olm authenticates the forwarding device, not the original room
            # sender. Imported history must never be labelled sender-verified.
            sessions$megolm_in[[key]] <- list(
                session = inbound,
                sender = pending$event_sender,
                sender_ed25519 = c$sender_claimed_ed25519_key %||%
                    NA_character_,
                sender_bound = FALSE)
            cancellations[[length(cancellations) + 1L]] <-
                mx_crypto_key_request_cancellation(pending)
            sessions$key_requests[[key]] <- NULL
        }
    }

    # 2. Room timelines: decrypt what we have keys for.
    events <- list()
    joined <- sync_resp$rooms$join %||% list()
    for (rid in names(joined)) {
        for (ev in joined[[rid]]$timeline$events %||% list()) {
            if (sas_is_event(ev)) {
                ev$room_id <- rid
                verification_events[[length(verification_events) + 1L]] <- ev
                next
            }
            if (!isTRUE(ev$type == "m.room.encrypted") ||
                !isTRUE(ev$content$algorithm == MX_MEGOLM)) {
                next
            }
            key <- paste(rid, ev$content$session_id, sep = "|")
            entry <- sessions$megolm_in[[key]]
            if (is.null(entry)) {
                # Older stores can have an outbound session without its local
                # inbound mirror. Do not request a key this device created.
                own_out <- sessions$megolm_out[[rid]]
                own_session_id <- if (is.null(own_out)) NULL else tryCatch(
                    mx.crypto::mxc_megolm_outbound_info(
                        own_out$session)$session_id,
                    error = function(e) NULL)
                if (identical(ev$content$session_id, own_session_id)) {
                    next
                }
                if (!is.null(self_id) && !is.null(self_device_id) &&
                    is.null(sessions$key_requests[[key]])) {
                    request <- mx_crypto_key_request(
                        self_id, self_device_id, rid,
                        ev$content$session_id,
                        ev$content$sender_key %||% NULL,
                        ev$sender %||% NA_character_)
                    sessions$key_requests[[key]] <- request
                }
                next
            }
            dec <- tryCatch(mx_crypto_decrypt_event(entry$session, ev$content),
                            error = function(e) NULL)
            if (!is.list(dec) || !is.list(dec$content)) {
                next
            }
            if (!identical(dec$room_id, rid)) {
                warning("mx.client: dropping encrypted event for a different room",
                    call. = FALSE)
                next
            }
            # The session was handed to us over Olm by whoever claimed the
            # identity recorded here. A disagreement with the envelope is a
            # forgery either way, so drop it. But agreement alone proves
            # nothing against a hostile homeserver, which writes both the
            # envelope and (via an injected to-device message) the claim.
            # Only a sender tied to a verified device counts as verified.
            attested <- entry$sender
            verified <- FALSE
            if (!is.null(attested) && !is.na(attested)) {
                if (!identical(attested, ev$sender)) {
                    warning("mx.client: dropping event ",
                            ev$event_id %||% "<no id>", " in ", rid,
                            ": envelope claims sender ",
                            ev$sender %||% "<missing>",
                            " but the Megolm session was shared by ",
                            attested, call. = FALSE)
                    next
                }
                verified <- isTRUE(entry$sender_bound)
            }
            ct <- dec$content
            if (sas_is_event(dec)) {
                # Some clients move the relation entirely outside the ciphertext.
                # Restore it before routing and commitment canonicalization.
                outer_relation <- ev$content$`m.relates_to`
                inner_relation <- ct$`m.relates_to`
                if (!is.null(outer_relation) && !is.null(inner_relation) &&
                    !isTRUE(tryCatch(identical(
                        mx.api::mx_canonical_json(outer_relation),
                        mx.api::mx_canonical_json(inner_relation)),
                        error = function(e) FALSE))) {
                    warning("mx.client: dropping verification with conflicting relations",
                        call. = FALSE)
                    next
                }
                if (is.null(inner_relation)) ct$`m.relates_to` <- outer_relation
                verification_events[[length(verification_events) + 1L]] <- list(
                    room_id = rid, event_id = ev$event_id, sender = ev$sender,
                    origin_server_ts = ev$origin_server_ts,
                    type = dec$type, content = ct, sender_verified = verified)
                next
            }
            events[[length(events) + 1L]] <- list(
                room_id = rid,
                event_id = ev$event_id,
                sender = ev$sender,
                sender_verified = verified,
                is_self = isTRUE(ev$sender == self_id),
                body = ct$body,
                msgtype = ct$msgtype,
                mentions = ct$`m.mentions`$user_ids
            )
        }
    }

    # A request is durable work until transport records a successful send.
    # Requeue unsent entries even after the original timeline event is gone.
    key_requests <- unname(Filter(
        function(request) !isTRUE(request$sent), sessions$key_requests))

    list(events = events, sessions = sessions,
         verification_events = verification_events,
         key_requests = key_requests,
         key_request_cancellations = cancellations,
         incoming_key_requests = incoming_requests)
}
