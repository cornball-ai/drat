#' bonsaisitter: Tree-Sitter Bindings for R
#'
#' R bindings to the tree-sitter parsing library with bundled R, Python, and
#' C++ grammars. Parses source code into concrete syntax trees for fast,
#' incremental analysis.
#'
#' @useDynLib bonsaisitter, .registration = TRUE
#' @keywords internal
"_PACKAGE"
