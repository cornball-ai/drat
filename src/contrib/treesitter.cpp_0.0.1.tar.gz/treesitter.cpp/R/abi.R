# The ABI version the bundled parser.c was generated with. Used to verify the
# grammar is compatible with the tree-sitter runtime consuming it.

abi <- function() {
  # ABI: 14
  14L
}
