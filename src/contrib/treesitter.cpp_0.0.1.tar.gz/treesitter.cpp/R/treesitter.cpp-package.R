#' @keywords internal
#' @useDynLib treesitter.cpp, .registration = TRUE
"_PACKAGE"
