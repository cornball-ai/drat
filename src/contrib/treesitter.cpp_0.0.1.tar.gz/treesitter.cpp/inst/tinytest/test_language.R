library(treesitter.cpp)

# -- language() returns a runtime-agnostic tree_sitter_language --
lang <- language()
expect_true(inherits(lang, "tree_sitter_language"))
expect_equal(lang$abi, 14L)
expect_equal(lang$name, "cpp")
expect_true(inherits(lang$pointer, "externalptr"))

# -- It works with a tree-sitter runtime, if one is installed --
if (requireNamespace("treesitter", quietly = TRUE)) {
  p <- treesitter::parser(language())
  tree <- treesitter::parser_parse(p, "int add(int x, int y) { return x + y; }\n")
  root <- treesitter::tree_root_node(tree)
  expect_equal(treesitter::node_type(root), "translation_unit")
  fn <- treesitter::node_child(root, 1)
  expect_equal(treesitter::node_type(fn), "function_definition")
}
