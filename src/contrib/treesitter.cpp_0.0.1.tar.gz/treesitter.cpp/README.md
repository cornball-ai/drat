# treesitter.cpp

A C++ grammar for [tree-sitter](https://tree-sitter.github.io/), packaged for R.
It ships the compiled `tree-sitter-cpp` grammar and exposes a single function,
`language()`, that returns a `tree_sitter_language` object. The grammar carries
no R dependencies and works with any tree-sitter runtime, including the
[treesitter](https://cran.r-project.org/package=treesitter) package and
`bonsaisitter`.

## Installation

```r
# install.packages("remotes")
remotes::install_github("cornball-ai/treesitter.cpp")
```

## Usage

```r
library(treesitter.cpp)

parser <- treesitter::parser(language())
tree <- treesitter::parser_parse(parser, "int add(int x, int y) { return x + y; }")
treesitter::tree_root_node(tree)
```

One use for a C++/C grammar is scaffolding: parse a header's concrete syntax
tree and walk it to generate R C API wrappers for its functions, structs, and
global definitions.

## Attribution

The bundled grammar and tree-sitter C headers are by the tree-sitter authors
(MIT). See `LICENSE` and `PROVENANCE`.
