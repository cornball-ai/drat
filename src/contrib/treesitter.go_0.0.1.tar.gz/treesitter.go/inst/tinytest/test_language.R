library(treesitter.go)

# -- language() returns a runtime-agnostic tree_sitter_language --
lang <- language()
expect_true(inherits(lang, "tree_sitter_language"))
expect_equal(lang$abi, 15L)
expect_equal(lang$name, "go")
expect_true(inherits(lang$pointer, "externalptr"))

# -- Runtime interop needs an ABI-15 runtime. Posit's treesitter caps at ABI 14
# -- and cannot load this grammar, so exercise it through bonsaisitter if present.
if (requireNamespace("bonsaisitter", quietly = TRUE)) {
  text <- "package main\n\nfunc add(x, y int) int {\n\treturn x + y\n}\n"
  p <- bonsaisitter::parser(language())
  tree <- bonsaisitter::parser_parse(p, text)
  root <- bonsaisitter::tree_root_node(tree)
  expect_equal(bonsaisitter::node_type(root), "source_file")
  expect_false(bonsaisitter::node_has_error(root))

  pkg <- bonsaisitter::node_child(root, 1)
  expect_equal(bonsaisitter::node_type(pkg), "package_clause")

  fn <- bonsaisitter::node_child(root, 2)
  expect_equal(bonsaisitter::node_type(fn), "function_declaration")
  expect_equal(
    bonsaisitter::node_text(bonsaisitter::node_child_by_field_name(fn, "name")),
    "add"
  )
}
