#' @keywords internal
#' @useDynLib treesitter.go, .registration = TRUE
"_PACKAGE"
