# The half of the Matrix adapter that needs mx.client installed: drift
# detection against its real signatures, the mapping run through the
# real extractor rather than a seam, and the typing and resolve paths
# that call into it directly. Splitting these out means the skip is
# announced. Folded into test_matrix.R behind a bare `if`, roughly 60%
# of the Matrix suite used to evaporate on a runner built with
# _R_CHECK_FORCE_SUGGESTS_=false and the badge stayed green.

if (!requireNamespace("mx.client", quietly = TRUE)) {
    exit_file("mx.client not installed")
}

# ---- API drift ----
# Membership is not enough: the adapter passes the first one or two
# arguments positionally, so an upstream reorder would keep every name
# present while the message body went out as the room id.

sync_formals <- names(formals(mx.client::mx_sync_update))
expect_true(all(c("client", "timeout", "save", "app", "filter") %in%
                sync_formals))
expect_identical(sync_formals[1L], "client")

# mx_sync_update's return is what carries first_run, and a silent
# removal is invisible at the call site: isTRUE(NULL) is FALSE, so every
# restart would replay its backfill as new mail with nothing erroring.
sync_body <- paste(deparse(body(mx.client::mx_sync_update)), collapse = " ")
expect_true(grepl("first_run", sync_body, fixed = TRUE))

extract_formals <- names(formals(mx.client::mx_extract_text_events))
expect_true(all(c("sync_resp", "self_id") %in% extract_formals))
expect_identical(extract_formals[1L], "sync_resp")

send_formals <- names(formals(mx.client::mx_send_text))
expect_true(all(c("room", "msgtype", "markdown", "mentions") %in%
                send_formals))
expect_identical(send_formals[1:2], c("client", "text"))

# chat_send passes room by name to mx_send_media; a rename upstream
# would silently fall back to the client's default room.
media_formals <- names(formals(mx.client::mx_send_media))
expect_identical(media_formals[1:2], c("client", "path"))
expect_true("room" %in% media_formals)

# chat_typing goes through a session, not the client config
expect_true("mx_client_session" %in% getNamespaceExports("mx.client"))
# chat_poll's token self-heal
expect_true("mx_with_relogin" %in% getNamespaceExports("mx.client"))

if (requireNamespace("mx.api", quietly = TRUE)) {
    # chat_typing passes room, typing state, and timeout by name
    typing_formals <- names(formals(mx.api::mx_typing))
    expect_true(all(c("room_id", "typing", "timeout") %in% typing_formals))
    expect_identical(typing_formals[1L], "session")
}

# ---- Markdown table route ----

# Matrix is the chat.api adapter where Markdown tables need a transport
# conversion: chat.api keeps the source as markdown, mx.client renders it to
# Matrix custom HTML, and mx.api receives the final event. Stub only the final
# mx.api network call so this exercises the real chat.api -> mx.client path.
if (requireNamespace("mx.api", quietly = TRUE)) {
    sent <- new.env()
    sent$args <- list()
    orig_mx_send <- mx.api::mx_send
    assignInNamespace("mx_send", function(session, room_id, body,
                                          msgtype = "m.text", extra = NULL) {
        sent$args[[length(sent$args) + 1L]] <<- list(
            session = session, room_id = room_id, body = body,
            msgtype = msgtype, extra = extra)
        "$table:ex"
    }, ns = "mx.api")
    on.exit(assignInNamespace("mx_send", orig_mx_send, ns = "mx.api"),
            add = TRUE)

    table_md <- paste(c(
        "| package | days per submission | latest |",
        "|---|---:|---:|",
        "| `llm.api` | 20.8 | 2026-06-26 |",
        "| `tinyrox` | 52.5 | 2026-06-24 |"
    ), collapse = "\n")
    p_table <- chat_matrix(mx = list(user_id = "@bot:ex",
                                     server = "https://ex.invalid",
                                     token = "tok", device_id = "DEV",
                                     room_id = "!default:ex"),
                           .sync = function(...) NULL,
                           .extract = function(...) list(),
                           .media = function(...) NULL)
    expect_identical(chat_send(p_table, "!room:ex", table_md,
                               markup = "markdown"), "$table:ex")
    routed <- sent$args[[1L]]
    expect_identical(routed$room_id, "!room:ex")
    expect_identical(routed$body, table_md)
    expect_identical(routed$msgtype, "m.text")
    expect_identical(routed$extra$format, "org.matrix.custom.html")
    expect_true(grepl("<table>", routed$extra$formatted_body, fixed = TRUE))
    expect_true(grepl("<td><code>llm.api</code></td>",
                      routed$extra$formatted_body, fixed = TRUE))
    expect_true(grepl("<td align=\"right\">20.8</td>",
                      routed$extra$formatted_body, fixed = TRUE))
}

# ---- Fixtures ----

fake_mx <- function(sync_token = NULL, room_id = NULL) {
    list(user_id = "@bot:ex", server = "https://ex.invalid",
         sync_token = sync_token, room_id = room_id)
}

# One human message, one from the bot itself, one m.notice. The bot's
# own event is tagged is_self by the extractor; the notice is dropped
# by its default msgtypes filter (see the asymmetry note below).
fake_sync <- list(rooms = list(join = list("!room:ex" = list(timeline = list(
    events = list(
        list(type = "m.room.message", event_id = "$1", sender = "@alice:ex",
             origin_server_ts = 1700000000000,
             content = list(msgtype = "m.text", body = "hello",
                            "m.mentions" = list(user_ids = list("@bot:ex")))),
        list(type = "m.room.message", event_id = "$2", sender = "@bot:ex",
             origin_server_ts = 1700000001000,
             content = list(msgtype = "m.text", body = "my own echo")),
        list(type = "m.room.message", event_id = "$3", sender = "@carol:ex",
             origin_server_ts = 1700000002000,
             content = list(msgtype = "m.notice", body = "a notice"))
    )
)))))

# ---- Poll through the real extractor ----
# Worth exercising for real rather than faking the record shape it
# produces: this is where the adapter's assumptions about that shape are
# either true of the installed build or not.

p <- chat_matrix(mx = fake_mx(), save_cursor = FALSE,
                 .sync = function(client, ...) {
                     list(sync = fake_sync, client = fake_mx("s_next"),
                          first_run = FALSE)
                 },
                 .send = function(...) "$id", .media = function(...) NULL)
got <- chat_poll(p)

expect_identical(got$cursor, "s_next")
expect_identical(p$env$mx$sync_token, "s_next")
expect_identical(got$raw, fake_sync)
expect_false(got$first_run)

# Self events are retained and flagged
expect_identical(length(got$messages), 2L)
expect_identical(vapply(got$messages, `[[`, "", "body"),
                 c("hello", "my own echo"))
expect_identical(vapply(got$messages, `[[`, logical(1), "self"),
                 c(FALSE, TRUE))

m <- got$messages[[1L]]
expect_identical(m$id, "$1")
expect_identical(m$channel, "!room:ex")
expect_identical(m$sender, "@alice:ex")
expect_identical(m$kind, "message")
expect_identical(m$mentions, "@bot:ex")

# The event's own time, by value. mx_extract_text_events only started
# carrying ts partway through mx.client 0.1.1.1's development, and
# builds either side of that share a version string, so this passes only
# if the adapter also reads origin_server_ts off the sync. A class-only
# assertion would have been satisfied by Sys.time().
expect_inherits(m$ts, "POSIXct")
expect_equal(as.numeric(m$ts), 1700000000, tolerance = 1e-6)
expect_equal(as.numeric(got$messages[[2L]]$ts), 1700000001, tolerance = 1e-6)

# Known asymmetry: chat_send can emit m.notice and m.emote, but
# mx_extract_text_events filters to m.text, so the adapter never
# receives what it can send. The notice above does not come back.
expect_false("a notice" %in% vapply(got$messages, `[[`, "", "body"))

# The extractor drops content$m.relates_to, so a threaded reply arrives
# with $thread empty and the relation unreachable from the message-level
# raw. thread_replies reports FALSE for exactly this reason.
expect_true(all(c("room_id", "event_id", "sender", "is_self", "body",
                  "msgtype", "mentions") %in% names(m$raw)))
expect_false("content" %in% names(m$raw))
expect_null(m$raw[["m.relates_to"]])
expect_false(chat_capabilities(p)$thread_replies)

# ---- Resolve ----
# Offline: mx_resolve_room short-circuits on a !-prefixed id and on an
# empty name, so both paths run without a homeserver.

r <- chat_matrix(mx = fake_mx(room_id = "!default:ex"),
                 .sync = function(...) NULL,
                 .extract = function(...) list(),
                 .send = function(...) "$id", .media = function(...) NULL)
# A literal room id passes through untouched
expect_identical(chat_resolve(r, "!real:ex"), "!real:ex")
# An empty name falls back to the client's default room rather than
# erroring. That is mx_resolve_room's fallback = TRUE default, and the
# adapter does not override it, so a caller that resolves an empty name
# posts into the default room. Pinned so the behaviour stays deliberate.
expect_identical(chat_resolve(r, ""), "!default:ex")
# With no default room there is nothing to fall back to, and it errors
# instead of returning NULL
no_default <- chat_matrix(mx = fake_mx(), .sync = function(...) NULL,
                          .extract = function(...) list(),
                          .send = function(...) "$id",
                          .media = function(...) NULL)
expect_error(chat_resolve(no_default, ""))

# ---- Typing ----

fake_send <- function(...) "$sent"
fake_media <- function(...) NULL

# Typing is best-effort: a client that cannot produce a session
# reports FALSE rather than propagating the error into a chat loop.
broken <- chat_matrix(mx = list(), .sync = function(...) NULL,
                      .extract = function(...) list(),
                      .send = fake_send, .media = fake_media)
expect_false(chat_typing(broken, "!room:ex", on = TRUE))

# The success path needs a config complete enough for
# mx_client_session(), so the real config -> session mapping runs;
# .typing stands in for the homeserver call.
typing_calls <- new.env()
typing_calls$args <- list()
fake_typing <- function(session, room_id, ...) {
    typing_calls$args[[length(typing_calls$args) + 1L]] <- c(
        list(session = session, room_id = room_id), list(...))
    invisible(NULL)
}
ty <- chat_matrix(mx = list(user_id = "@bot:ex",
                            server = "https://ex.invalid",
                            token = "tok", device_id = "DEV"),
                  .sync = function(...) NULL,
                  .extract = function(...) list(),
                  .send = fake_send, .media = fake_media,
                  .typing = fake_typing)

expect_true(chat_typing(ty, "!room:ex"))
t1 <- typing_calls$args[[1L]]
expect_inherits(t1$session, "mx_session")
expect_identical(t1$room_id, "!room:ex")
expect_true(t1$typing)
# Default is 30 seconds, converted to the milliseconds mx.api wants
expect_identical(t1$timeout, 30000L)

# A caller working through a slow model turn picks its own window
expect_true(chat_typing(ty, "!room:ex", on = TRUE, timeout = 120))
expect_identical(typing_calls$args[[2L]]$timeout, 120000L)

# ... and clears it afterwards: the off path goes out as
# typing = FALSE rather than being dropped or inverted
expect_true(chat_typing(ty, "!room:ex", on = FALSE))
expect_false(typing_calls$args[[3L]]$typing)

# A NULL timeout falls back to the default instead of erroring
chat_typing(ty, "!room:ex", timeout = NULL)
expect_identical(typing_calls$args[[4L]]$timeout, 30000L)

# A failing homeserver call is still swallowed, seam or not
boom <- chat_matrix(mx = list(user_id = "@bot:ex",
                              server = "https://ex.invalid",
                              token = "tok", device_id = "DEV"),
                    .sync = function(...) NULL,
                    .extract = function(...) list(),
                    .send = fake_send, .media = fake_media,
                    .typing = function(...) stop("homeserver down"))
expect_false(chat_typing(boom, "!room:ex"))
