# <unlabeled code block>
library(RcppOTIO)

# <unlabeled code block>
rt <- RationalTime(48, 24)   # 48 frames at 24 fps
to_seconds(rt)
to_timecode(rt, 24)

tr <- TimeRange(RationalTime(0, 24), RationalTime(48, 24))
to_seconds(duration(tr))
to_seconds(end_time_exclusive(tr))

# <unlabeled code block>
RationalTime(10, 24) + RationalTime(5, 24)
RationalTime(10, 24) < RationalTime(20, 24)

# <unlabeled code block>
tl  <- Timeline("my timeline")
trk <- Track("V1", kind = "Video")

clipA <- Clip("A",
              ExternalReference("a.mov",
                                available_range = TimeRange(RationalTime(0, 24),
                                                            RationalTime(240, 24))),
              source_range = TimeRange(RationalTime(0, 24), RationalTime(48, 24)))
clipB <- Clip("B", source_range = TimeRange(RationalTime(0, 24), RationalTime(24, 24)))

append_child(trk, clipA)
append_child(trk, clipB)
append_child(tracks(tl), trk)

length(find_clips(tl))
to_seconds(duration(tl))

# <unlabeled code block>
to_seconds(start_time(range_in_parent(clipB)))

# <unlabeled code block>
index_of_child(trk, clipB)
name(children(trk)[[1]])

# <unlabeled code block>
proxy  <- ExternalReference("proxy.mov")
master <- ExternalReference("master.mov")
clip   <- Clip("shot")
set_media_references(clip, list(proxy = proxy, master = master),
                     new_active_key = "master")

names(media_references(clip))
active_media_reference_key(clip)
target_url(media_reference(clip))

# <unlabeled code block>
edit <- Track("V1", kind = "Video")
append_child(edit, Clip("A", source_range = TimeRange(RationalTime(0, 24), RationalTime(48, 24))))
append_child(edit, Clip("B", source_range = TimeRange(RationalTime(0, 24), RationalTime(48, 24))))

slice(edit, RationalTime(24, 24))
vapply(children(edit), name, character(1))

over <- Clip("C", source_range = TimeRange(RationalTime(0, 24), RationalTime(24, 24)))
overwrite(over, edit, TimeRange(RationalTime(24, 24), RationalTime(24, 24)))
vapply(children(edit), name, character(1))

# <unlabeled code block>
js  <- to_json_string(tl)
tl2 <- from_json_string(js)
is_equivalent_to(tl, tl2)

f <- tempfile(fileext = ".otio")
to_json_file(tl, f)
identical(schema_name(from_json_file(f)), "Timeline")
unlink(f)

# <unlabeled code block>
tvm <- type_version_map()
tvm[["Clip"]]

clip <- Clip("c", media_reference = ExternalReference("a.mov"))
older <- to_json_string(clip, target_schema_versions = c(Clip = 1L))
grepl("Clip.1", older, fixed = TRUE)

