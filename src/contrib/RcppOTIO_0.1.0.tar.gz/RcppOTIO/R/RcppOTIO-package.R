#' RcppOTIO: R Bindings for OpenTimelineIO
#'
#' An Rcpp wrapper over the OpenTimelineIO (OTIO) C++ library. The OTIO
#' time value types (\code{RationalTime}, \code{TimeRange},
#' \code{TimeTransform}) are represented as plain classed R values, while
#' the serializable schema objects (\code{Timeline}, \code{Stack},
#' \code{Track}, \code{Clip}, and the rest) are held behind external
#' pointers with OTIO's intrusive reference counting.
#'
#' Names follow OTIO exactly: \code{source_range}, \code{range_in_parent},
#' \code{append_child}, and so on. Tree children are addressed by position
#' and object reference, never by name.
#'
#' Because the names are faithful to OTIO, attaching the package with
#' \code{library(RcppOTIO)} masks a few base functions: \code{comment} and
#' \code{comment<-} (the \code{Marker} comment accessors) and
#' \code{remove} (the edit algorithm; base \code{remove} is the alias of
#' \code{rm}). Use \code{RcppOTIO::} / \code{base::} to disambiguate if you
#' need both.
#'
#' @useDynLib RcppOTIO, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @name RcppOTIO-package
#' @keywords internal
"_PACKAGE"
